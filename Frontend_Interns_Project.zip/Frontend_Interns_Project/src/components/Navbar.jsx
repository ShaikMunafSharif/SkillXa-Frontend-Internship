import { Link } from 'react-router-dom';
import { Search, ShoppingCart, User } from 'lucide-react';

export default function Navbar() {
  return (
    <nav className="fixed top-0 w-full z-50 bg-white/80 dark:bg-slate-950/80 backdrop-blur-xl shadow-[0_20px_40px_rgba(124,58,237,0.04)] transition-colors duration-500">
      <div className="flex justify-between items-center max-w-7xl mx-auto px-8 h-20">
        <Link to="/homepage" className="text-2xl font-black tracking-tighter text-violet-600 dark:text-violet-400">
          AURA
        </Link>
        <div className="hidden md:flex items-center gap-8">
          <Link to="/deals" className="font-epilogue tracking-tight text-sm uppercase font-semibold text-slate-600 dark:text-slate-400 hover:text-violet-500 dark:hover:text-violet-300 transition-all duration-300">
            New Arrivals
          </Link>
          <Link to="/products" className="font-epilogue tracking-tight text-sm uppercase font-semibold text-slate-600 dark:text-slate-400 hover:text-violet-500 dark:hover:text-violet-300 transition-all duration-300">
            Collections
          </Link>
          <Link to="/wishlist" className="font-epilogue tracking-tight text-sm uppercase font-semibold text-slate-600 dark:text-slate-400 hover:text-violet-500 dark:hover:text-violet-300 transition-all duration-300">
            Wishlist
          </Link>
          <Link to="/deals" className="font-epilogue tracking-tight text-sm uppercase font-semibold text-slate-600 dark:text-slate-400 hover:text-violet-500 dark:hover:text-violet-300 transition-all duration-300">
            Deals
          </Link>
        </div>
        <div className="flex items-center gap-6">
          <Link to="/search" className="scale-95 active:scale-90 transition-transform text-slate-600 dark:text-slate-400 hover:text-violet-500">
            <Search size={24} />
          </Link>
          <Link to="/cart" className="scale-95 active:scale-90 transition-transform text-slate-600 dark:text-slate-400 hover:text-violet-500">
            <ShoppingCart size={24} />
          </Link>
          <Link to="/login " className="scale-95 active:scale-90 transition-transform text-slate-600 dark:text-slate-400 hover:text-violet-500">
            <User size={24} />
          </Link>
        </div>
      </div>
    </nav>
  );
}
