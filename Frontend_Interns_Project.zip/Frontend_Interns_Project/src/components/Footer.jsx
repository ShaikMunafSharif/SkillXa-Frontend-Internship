import { Link } from 'react-router-dom';
import { Globe, Camera } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-50 dark:bg-slate-900 w-full border-t border-slate-100 dark:border-slate-800 mt-auto">
      <div className="flex flex-col md:flex-row justify-between items-center py-16 px-8 max-w-7xl mx-auto gap-8">
        <div className="flex flex-col gap-4 text-center md:text-left">
          <div className="text-xl font-bold text-violet-600 dark:text-violet-400">AURA</div>
          <p className="font-epilogue text-xs tracking-widest uppercase text-slate-400 dark:text-slate-500 max-w-[280px]">
            © 2024 AURA Boutique. Designed for the discerning.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-8 md:gap-12">
          <Link to="#" className="font-epilogue text-xs tracking-widest uppercase text-slate-400 dark:text-slate-500 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">Privacy Policy</Link>
          <Link to="#" className="font-epilogue text-xs tracking-widest uppercase text-slate-400 dark:text-slate-500 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">Terms of Service</Link>
          <Link to="#" className="font-epilogue text-xs tracking-widest uppercase text-slate-400 dark:text-slate-500 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">Sustainability</Link>
          <Link to="#" className="font-epilogue text-xs tracking-widest uppercase text-slate-400 dark:text-slate-500 hover:text-violet-600 dark:hover:text-violet-400 transition-colors">Contact Us</Link>
        </div>
        <div className="flex gap-6">
          <a href="#" className="text-slate-400 hover:text-primary transition-colors">
            <Globe size={24} />
          </a>
          <a href="#" className="text-slate-400 hover:text-primary transition-colors">
            <Camera size={24} />
          </a>
        </div>
      </div>
    </footer>
  );
}
