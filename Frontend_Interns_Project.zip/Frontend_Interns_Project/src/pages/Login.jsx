import React, { useState } from 'react';
import { Mail, Lock, ArrowRight } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export default function Login() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    // Simulate login and redirect
    navigate('/');
  };

  return (
    <div className="min-h-screen flex bg-background">
      {/* Left side - Branding/Illustration */}
      <div className="hidden lg:flex w-1/2 bg-gradient-to-br from-primary to-primary-container text-on-primary p-12 flex-col justify-between relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-[-10%] left-[-10%] w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-96 h-96 bg-white/10 rounded-full blur-3xl"></div>
        <div className="absolute top-[40%] right-[-5%] w-64 h-64 bg-secondary/20 rounded-full blur-3xl"></div>

        <div className="relative z-10">
          <Link to="/" className="flex items-center gap-2 w-max transition-transform hover:scale-105">
            <div className="w-10 h-10 bg-on-primary rounded-lg flex items-center justify-center shadow-lg">
              <span className="text-primary font-bold text-xl font-epilogue">L</span>
            </div>
            <span className="text-2xl font-bold font-epilogue tracking-tight">Luxe</span>
          </Link>
        </div>

        <div className="relative z-10 max-w-md">
          <div className="inline-block px-4 py-1.5 rounded-full bg-white/20 backdrop-blur-md border border-white/20 text-sm font-semibold mb-6">
            ✨ Welcome Back to Luxe
          </div>
          <h1 className="text-5xl font-bold font-epilogue leading-tight mb-6">
            Discover Your Next Obsession
          </h1>
          <p className="text-lg text-on-primary/80 font-manrope leading-relaxed">
            Sign in to access exclusive drops, personalized recommendations, and a seamless shopping experience curated just for you.
          </p>

          <div className="mt-12 flex items-center gap-4">
            <div className="flex -space-x-3">
              <img className="w-10 h-10 rounded-full border-2 border-primary-container" src="https://i.pravatar.cc/100?img=1" alt="User" />
              <img className="w-10 h-10 rounded-full border-2 border-primary-container" src="https://i.pravatar.cc/100?img=2" alt="User" />
              <img className="w-10 h-10 rounded-full border-2 border-primary-container" src="https://i.pravatar.cc/100?img=3" alt="User" />
            </div>
            <p className="text-sm font-medium">Join 10k+ fashion enthusiasts</p>
          </div>
        </div>

        <div className="relative z-10 text-sm text-on-primary/60 font-manrope">
          © {new Date().getFullYear()} Luxe E-Commerce. All rights reserved.
        </div>
      </div>

      {/* Right side - Form */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 sm:p-12 lg:p-24 relative">
        <div className="w-full max-w-md">
          <div className="mb-10 text-center lg:text-left">
            <h2 className="text-4xl font-bold text-on-background font-epilogue mb-3">Sign In</h2>
            <p className="text-on-surface-variant font-manrope text-lg">Please enter your details to access your account.</p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="space-y-2 text-left">
              <label className="text-sm font-semibold text-on-surface block font-manrope">Email Address</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-outline group-focus-within:text-primary transition-colors">
                  <Mail size={20} />
                </div>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-11 pr-4 py-3.5 bg-surface-container-lowest border border-outline-variant rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none text-on-surface font-manrope shadow-sm hover:border-outline"
                  placeholder="name@example.com"
                  required
                />
              </div>
            </div>

            <div className="space-y-2 text-left">
              <div className="flex justify-between items-center">
                <label className="text-sm font-semibold text-on-surface block font-manrope">Password</label>
                <a href="#" className="text-sm text-primary font-semibold hover:text-primary-container transition-colors font-manrope">
                  Forgot password?
                </a>
              </div>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-outline group-focus-within:text-primary transition-colors">
                  <Lock size={20} />
                </div>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-11 pr-4 py-3.5 bg-surface-container-lowest border border-outline-variant rounded-xl focus:ring-2 focus:ring-primary focus:border-transparent transition-all outline-none text-on-surface font-manrope shadow-sm hover:border-outline"
                  placeholder="Enter your password"
                  required
                />
              </div>
            </div>

            <div className="flex items-center gap-3 pt-1">
              <input type="checkbox" id="remember" className="w-4.5 h-4.5 rounded text-primary focus:ring-primary border-outline-variant cursor-pointer transition-all" />
              <label htmlFor="remember" className="text-sm text-on-surface-variant font-manrope cursor-pointer select-none">Remember me for 30 days</label>
            </div>

            <button
              type="submit"
              className="w-full bg-primary hover:bg-primary-container text-on-primary py-4 rounded-xl font-bold font-manrope transition-all flex justify-center items-center gap-2 group shadow-[0_4px_14px_0_rgba(99,14,212,0.39)] hover:shadow-[0_6px_20px_rgba(99,14,212,0.23)] hover:-translate-y-0.5 cursor-pointer"
            >
              Sign In to Luxe
              <ArrowRight size={18} className="group-hover:translate-x-1.5 transition-transform" />
            </button>
          </form>

          <div className="mt-8 flex items-center gap-4">
            <div className="h-[1px] flex-1 bg-outline-variant/50"></div>
            <span className="text-on-surface-variant text-sm font-manrope font-medium">Or continue with</span>
            <div className="h-[1px] flex-1 bg-outline-variant/50"></div>
          </div>

          <div className="mt-8 grid grid-cols-2 gap-4">
            <button className="flex items-center justify-center gap-2.5 py-3.5 bg-surface-container-lowest border border-outline-variant rounded-xl text-on-surface font-semibold hover:bg-surface-container transition-all font-manrope shadow-sm hover:shadow hover:-translate-y-0.5 cursor-pointer">
              <svg className="w-5 h-5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" fill="#FBBC05" />
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
              </svg>
              Google
            </button>
            <button className="flex items-center justify-center gap-2.5 py-3.5 bg-surface-container-lowest border border-outline-variant rounded-xl text-on-surface font-semibold hover:bg-surface-container transition-all font-manrope shadow-sm hover:shadow hover:-translate-y-0.5 cursor-pointer">
              {/* <Github size={20} className="text-[#151c27]" /> */}
              GitHub
            </button>
          </div>

          <p className="mt-10 text-center text-on-surface-variant font-manrope">
            Don't have an account?{' '}
            <Link to="/signup" className="text-primary font-bold hover:text-primary-container hover:underline transition-all">
              Sign up for free
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
