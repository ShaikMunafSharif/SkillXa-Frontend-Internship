import { ArrowRight, Search, ShoppingCart, User, Plus } from 'lucide-react';

export default function HomePage() {
  return (
    <>
      {/* Hero Section */}
      <section className="relative min-h-[921px] flex items-center overflow-hidden bg-gradient-to-br from-primary-container/40 to-transparent">
        <div className="max-w-7xl mx-auto px-8 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="z-10">
            <span className="font-label-md text-primary tracking-widest uppercase mb-6 block">Collection 2024</span>
            <h1 className="font-display-xl text-on-surface mb-8">Ethereal <br/><span className="text-primary">Essentials.</span></h1>
            <p className="font-body-lg text-on-surface-variant max-w-lg mb-12">Redefining the digital boutique through architectural precision and serene minimalism. Curated for the discerning eye.</p>
            <div className="flex items-center gap-6">
              <button className="bg-primary-container text-on-primary font-button px-12 py-5 rounded-full scale-95 active:scale-90 transition-transform shadow-[0_10px_20px_rgba(99,14,212,0.2)]">Shop The Look</button>
              <button className="font-button text-primary px-8 py-5 flex items-center gap-2 hover:translate-x-2 transition-transform">
                View Lookbook <ArrowRight size={20} />
              </button>
            </div>
          </div>
          <div className="relative">
            <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-[0_40px_80px_rgba(124,58,237,0.1)] scale-105 rotate-2">
              <img alt="Model in minimalist fashion" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuB8i96fE8DUhSq3ofKrinrUnGlGU1HKe4E5BRZb26VYnxmPU0j5ptMnvH7j1aSZc9AriYHFgkq7TPtuO9Qa6RjED779b3IkzLPpzXBNvMmSUevnRJU__UNKuY0QL3iIPKla35n3A33j7-BDxxTeB2VrOrYS_kZJuDk9pB-0uvVlvgkDp-VVXyD9RsHRFrtdNIGeOEPcc6gKfceArbrdGBBZTk0D4K4Y1CtJJm1tQBDr24t7N9Teg5UpVdMr76rSYmUvDn4OfJJs1O-L"/>
            </div>
            <div className="absolute -bottom-10 -left-10 aspect-square w-64 rounded-2xl overflow-hidden shadow-2xl -rotate-6 border-8 border-white">
              <img alt="Textured detail" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDysaVlWY8omybHxVQLECMtHxwUFcMsXBo8mm-0QIqdDVrTc-iy1nwv0vXFFBXSSQfYtZswEW6qcLube1CmEUHE7piRqU9GWbPBYb1vPj3AcFJvV8gFoji5O8QYEtEgZpg_X2l-wdmHULBlro3r61jqR6kOGFSzbPNa7KKijcM4pCfTN6mAiOU2FTG8xzNPhD9dMCwZ8dyr62RRMYolxVVLIcYH6HrDEcvEb6m7ktlGwSPKVUdXBdp2GAkmxVYd8lCxaBmyYhIVi5nZ"/>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Bento Grid */}
      <section className="max-w-7xl mx-auto px-8 py-32">
        <div className="flex justify-between items-end mb-16">
          <div>
            <h2 className="font-headline-lg text-on-surface">Curation</h2>
            <p className="font-body-md text-on-surface-variant">Explore by architectural category</p>
          </div>
        </div>
        <div className="grid grid-cols-12 gap-8 h-[700px]">
          <div className="col-span-12 md:col-span-8 group relative rounded-3xl overflow-hidden bg-surface-container-low shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <img alt="Apparel" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDGg3GFn-59rFEZnUkh4qFNVlGjlvapaB-4GbxFsx31tRyfyCDoOc-sVZuVMzl86SEMPTlWRg6Q-rIe7bSm6mtKClYFh1zU1nt7Aj-zXSKiV5SLSoLy6b4s0ihJhKf5jZYW-Gr9GNBt-weVEv5N0LB0tWxw9rEoho3rTxmbV7eibDWEy5IQLB4J0on61ctJDEXyCCBQh5tsKaR9mglb-krqoZzEztlDkggUiUAR5As8xjcmQEMFPPUbdk1RO52bLPD0FZ8YEKQ4402e"/>
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent p-12 flex flex-col justify-end">
              <h3 className="font-headline-md text-white">Prêt-à-Porter</h3>
              <p className="font-body-md text-white/80">Refined silhouettes for everyday elegance</p>
            </div>
          </div>
          <div className="col-span-12 md:col-span-4 group relative rounded-3xl overflow-hidden bg-surface-container-low shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <img alt="Accessories" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBCzwWDasCknGnLZQITuzDMHycmX-Lk3XOV3-dqoErdTpzl68sYTHruPB_Uyixp_roHHSjloaV8nTYTZhzFZmnRULsAONTPC-T9uUDILEdh5Wc-9vLOnuM4sDK3okXcZ9-SzgU_Z-qDpE2OxlKKSQYOYTAR8bh0iktKeHlmsTR-oUQAtpAsmE8aagQy8YUDu1bJgiy9fnBRRralyzXxaOCpOxCl4UP5gGyga7cn8ztN47IY9fkihuttFGD0L-kV2wX-IJWXLhp3ngok"/>
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent p-12 flex flex-col justify-end">
              <h3 className="font-headline-md text-white">Objet</h3>
              <p className="font-body-md text-white/80">Fine leather goods</p>
            </div>
          </div>
          <div className="col-span-12 md:col-span-4 group relative rounded-3xl overflow-hidden bg-surface-container-low shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <img alt="Footwear" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBg7-Rr8y2dKETX0iTEMGiGw1oXYhZIdW7iImc6Kzzp9BfVYILLUOI-sKdN1aYCqaOwad5RXdntwDdvp_BTk8v-sQUlKCyVBcw4lsBGI7mxMiE6E0ff4mulBsRHonf9-h0oDyEFOjJzs_ngoUObRBr-r9jmsJGyTnCSJ3rQ2JgLqbAQqNqKORNYvRNM1sJnbPi9jZhHpDEBATLIGNAshRCvhr6py_1k6h8awsPudh6ySJENukAYb5xnKwgpbM0tgZgm2pg5qFrHBtM2"/>
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent p-12 flex flex-col justify-end">
              <h3 className="font-headline-md text-white">Walk</h3>
              <p className="font-body-md text-white/80">Sculptural footwear</p>
            </div>
          </div>
          <div className="col-span-12 md:col-span-8 group relative rounded-3xl overflow-hidden bg-surface-container-low shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <img alt="Fragrance" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAIFg5L_CJMR11JqLa4gWq0sr3CXcZWsDbbBbvc1hvKD5lJfPKiaTlv6gjXhIa0Z2LQh9mfJaxP_02D7m8up-1Xw0OOfVpnpCB6ulySR-sChjLAh5rr8K-YhguBbDP83QOWMgw6Lv1VvhqsTlPWfGsIn7-j_t5PSKBNBOGR1CkZXqyknxzHtkZDa9qkNKBXdR3ZJNZyfJAHINMrleFU7Epp1TLf75bCoLqE9v8C_9mQ7Wvh9lRweAh70MT-495ld8zRuTgVUYRgT5aL"/>
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent p-12 flex flex-col justify-end">
              <h3 className="font-headline-md text-white">Essence</h3>
              <p className="font-body-md text-white/80">Signature scents</p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="bg-surface-container-low py-32">
        <div className="max-w-7xl mx-auto px-8">
          <div className="text-center mb-24">
            <span className="font-label-md text-primary tracking-widest uppercase mb-4 block">New Arrivals</span>
            <h2 className="font-headline-lg text-on-surface">The Edit: Volume I</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            {[
              {
                id: 1,
                name: "Structured Wool Blazer",
                price: "$420",
                color: "Sandstone Melange",
                image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCLy9ZqN42D12Q3FeBi22QgaYp04bHJbV_0Q98s0D8nEi_J0kCxTYgDvh-Fa-yXaHzMfKZG3MpGqvkS6JFeqRcFlJN3UpuLubZVYmHuKCCGcifG0Bg-jwM-W6HUgx6bHEHm12L_4UjJBNyvRqCKsJYbL8wqb4AVeCXs1oMcYEvLxNAretFH4v7AuD-JKIQupPTUF8Pv5DLa_vhKHDasjGpkGle1lXXQLKEVT7dsN4v-2A-RFRqq-H8LsdPvWx-OlOIJT_E8at1cnaU6"
              },
              {
                id: 2,
                name: "Architectural Denim",
                price: "$280",
                color: "Indigo Raw",
                image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDKf9ZME8ui557xYDQZn2CyXSVJWY1NYVI6egYMhSYw2DfMITKPUiB39hMtlOs6f0sPjK894vGHHesNVQMVHpUp0xwt7HWSxDpVRMNGKph9bscvxhQSYDiIEtH_K7aD12IQFYNv6Vt6XIk9EF6YIsXkCthx7FYf6HvNaXt1qb4T08YKDJzRq6ftrDE7Rn-91frz-UOQEOCFdnRaC6NCKF2ZE40nUmNM9m9SsjdTqVEFWlPtDzgOQYQq6lEgUjGUFRM4iTTXLvwsrwYm"
              },
              {
                id: 3,
                name: "Glass Heel Mules",
                price: "$560",
                color: "Cobalt Sheer",
                image: "https://lh3.googleusercontent.com/aida-public/AB6AXuD2rtaXID5TYUhAffmrJQr_VZaFQdjAawEQTyH9p92w_BfxEyimtAOH13_ErcAsO1_AmzYjVyYUWEmKjgwtA04MmqiUoyiFbeLKTqSgMxJow9zPad017KYvgqfwXyVMNrR0MY7aPZQQzkhYgAYseElrpJs3kam5Y7Jvn65nFlM7_DzKrDuWq8Ut_2LUvD8Xb1afZmWpReIAuYw8X41BFRTk8ih67KyPBVMaUXRvwpiGL6jMnGrmjeeUDtTAOS7hMrTT_gOvlTzYzWIr"
              }
            ].map(product => (
              <div key={product.id} className="group">
                <div className="aspect-[3/4] rounded-2xl overflow-hidden mb-8 bg-white relative">
                  <img alt={product.name} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" src={product.image} />
                  <button className="absolute top-6 right-6 w-12 h-12 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center text-primary opacity-0 group-hover:opacity-100 transition-opacity">
                    <span className="material-symbols-outlined">favorite</span>
                  </button>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <h4 className="font-headline-md text-xl">{product.name}</h4>
                    <span className="font-body-md text-primary font-bold">{product.price}</span>
                  </div>
                  <p className="font-body-md text-on-surface-variant">{product.color}</p>
                  <button className="font-button text-primary pt-4 flex items-center gap-2 group-hover:gap-4 transition-all">
                    Quick Shop <Plus size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter */}
      <section className="max-w-7xl mx-auto px-8 py-32">
        <div className="bg-primary-container rounded-[3rem] p-16 md:p-24 relative overflow-hidden flex flex-col items-center text-center">
          <div className="absolute inset-0 opacity-20 pointer-events-none">
            <div className="absolute -top-1/2 -left-1/4 w-[150%] h-[150%] bg-[radial-gradient(circle,rgba(255,255,255,0.4)_0%,transparent_70%)]"></div>
          </div>
          <h2 className="font-display-xl text-white mb-8 z-10">Join The <br/>AURA Circle</h2>
          <p className="font-body-lg text-white/80 max-w-xl mb-12 z-10">Sign up for early access to limited edition drops, seasonal lookbooks, and private event invitations.</p>
          <form className="flex flex-col md:flex-row gap-4 w-full max-w-lg z-10" onSubmit={(e) => e.preventDefault()}>
            <input className="flex-grow bg-white/10 border-0 rounded-full px-8 py-5 text-white placeholder:text-white/60 focus:ring-2 focus:ring-white outline-none backdrop-blur-sm" placeholder="Your email address" type="email" />
            <button className="bg-white text-primary font-button px-12 py-5 rounded-full hover:bg-surface transition-colors" type="submit">Subscribe</button>
          </form>
        </div>
      </section>
    </>
  );
}
