import { Check, Package, Truck, Home, MessageSquare } from 'lucide-react';

const trackingUpdates = [
  {
    id: 1,
    status: "Departed Sorting Facility",
    location: "North Bergen, New Jersey, US",
    time: "Oct 22, 09:42 PM",
    isCurrent: true
  },
  {
    id: 2,
    status: "Arrived at FedEx Location",
    location: "North Bergen, New Jersey, US",
    time: "Oct 22, 11:15 AM",
    isCurrent: false
  },
  {
    id: 3,
    status: "Package has left the facility",
    location: "Los Angeles, California, US",
    time: "Oct 21, 04:30 PM",
    isCurrent: false
  }
];

const orderItems = [
  {
    id: 1,
    name: "Sculpted Trench Coat",
    details: "Size: M | Color: Sand",
    price: 450.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAubmGlDjkRFPG9f3luDp2Yy0_TPtcRoV4AN5Uzv21K8NLqwq5q7p7951X5kHhnwq0JsSGPmZ9NrZEoCUr1BHvAu6Ye7dFVNztcfrBY8eOxZzy4mQibm2sJzXsYiWSpEihXxBoyHS8_QG_vN6alxKlI_z6E21Ziye-08KNpXNlwmyUfQ10F0Ni8CcfBTQCvzmPmglCgEcjeRhrEBFR-LY4zbesNnoPirsFRHQVkPlbCyrhsb6VzHW_Xf-p_VqKK93fJl4Ud1nPta6ac"
  },
  {
    id: 2,
    name: "Lumina Leather Sneakers",
    details: "Size: 42 | Color: Bone",
    price: 280.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDaXXEu-F0PL2lNT1LxqqBqG17KDcCs3VuFQkAZbYFYXhlnP5WRisue1xuy7dnP4olqxHziAPIpjbprAH4NC0bZ2xQNp6Da4X4t32ciewrEG7NGIdH3MOXGB9sX8atYVKF0krtrquJkKGiMl04BPSZMTpNmKJ1oNVx_joXoa8x97nLyfpKVl30h3fSEecMpFWyN9r8JbYZohyiy84NgqFQhyHm_S4J-tRsK4wk-KwIx-OdQAbGKJr0oGa6DN87v8PqtCcDekh6wYAW0"
  }
];

export default function OrderTracking() {
  const subtotal = orderItems.reduce((sum, item) => sum + item.price, 0);
  const tax = subtotal * 0.085; // $62.05 / $730.00
  const total = subtotal + tax;

  return (
    <div className="py-12 px-8 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
        <div className="lg:col-span-8 space-y-8">
          {/* Tracking Header and Progress */}
          <section className="bg-surface-container-lowest p-8 rounded-xl shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-12">
              <div>
                <span className="font-label-md text-primary uppercase tracking-widest text-xs">Order #AU-982104</span>
                <h1 className="font-headline-md text-3xl text-on-surface mt-2">In Transit</h1>
                <p className="font-body-md text-on-surface-variant mt-1">Estimated delivery: <span className="font-semibold text-on-surface">Thursday, Oct 24</span></p>
              </div>
              <div className="bg-surface-container-low px-4 py-3 rounded-lg flex items-center gap-3">
                <Truck className="text-primary" size={20} />
                <span className="font-label-md text-on-surface">Track via FedEx: 77291038442</span>
              </div>
            </div>

            {/* Progress Bar */}
            <div className="relative py-12">
              <div className="absolute top-1/2 left-0 w-full h-1 bg-surface-container-high -translate-y-1/2 rounded-full overflow-hidden">
                <div className="h-full bg-primary w-2/3 transition-all duration-1000"></div>
              </div>
              
              <div className="relative z-10 flex justify-between">
                <div className="flex flex-col items-center text-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-lg shadow-primary/20">
                    <Check size={24} />
                  </div>
                  <span className="font-label-md text-xs uppercase text-on-surface">Confirmed</span>
                </div>
                
                <div className="flex flex-col items-center text-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-lg shadow-primary/20">
                    <Package size={24} />
                  </div>
                  <span className="font-label-md text-xs uppercase text-on-surface">Packed</span>
                </div>
                
                <div className="flex flex-col items-center text-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-primary text-on-primary flex items-center justify-center shadow-lg shadow-primary/20 ring-4 ring-white">
                    <Truck size={24} />
                  </div>
                  <span className="font-label-md text-xs uppercase text-primary font-bold">In Transit</span>
                </div>
                
                <div className="flex flex-col items-center text-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-surface-container-high text-outline flex items-center justify-center">
                    <Home size={24} />
                  </div>
                  <span className="font-label-md text-xs uppercase text-outline">Delivered</span>
                </div>
              </div>
            </div>
          </section>

          {/* Shipping Updates */}
          <section className="bg-surface-container-lowest p-8 rounded-xl shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <h2 className="font-headline-md text-2xl mb-8 text-on-surface">Shipping Updates</h2>
            
            <div className="space-y-8 relative before:absolute before:left-[11px] before:top-2 before:bottom-2 before:w-[2px] before:bg-surface-container-high">
              {trackingUpdates.map((update, index) => (
                <div key={update.id} className="relative pl-10">
                  {update.isCurrent ? (
                    <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-primary-container flex items-center justify-center ring-4 ring-white">
                      <div className="w-2 h-2 rounded-full bg-white"></div>
                    </div>
                  ) : (
                    <div className="absolute left-0 top-1 w-6 h-6 rounded-full bg-surface-container-high flex items-center justify-center">
                      <div className="w-2 h-2 rounded-full bg-outline"></div>
                    </div>
                  )}
                  
                  <div className="flex flex-col md:flex-row justify-between gap-2">
                    <div>
                      <h4 className="font-label-md text-on-surface">{update.status}</h4>
                      <p className="font-body-md text-sm text-on-surface-variant mt-1">{update.location}</p>
                    </div>
                    <span className="font-label-md text-xs text-outline whitespace-nowrap mt-1 md:mt-0">{update.time}</span>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-4 space-y-8">
          <div className="bg-surface-container-lowest p-8 rounded-xl shadow-[0_20px_40px_rgba(124,58,237,0.04)] border border-surface-variant">
            <h3 className="font-headline-md text-xl mb-6 text-on-surface">Order Summary</h3>
            
            <div className="space-y-6">
              {orderItems.map(item => (
                <div key={item.id} className="flex gap-4">
                  <img alt={item.name} className="w-20 h-20 rounded-lg object-cover bg-surface-container-low flex-shrink-0" src={item.image} />
                  <div className="flex flex-col justify-center">
                    <h4 className="font-label-md text-on-surface leading-tight">{item.name}</h4>
                    <p className="text-sm text-outline mt-1">{item.details}</p>
                    <p className="font-label-md mt-1 text-on-surface">${item.price.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-8 pt-8 border-t border-surface-container-high space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-on-surface-variant">Subtotal</span>
                <span className="font-semibold text-on-surface">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-on-surface-variant">Shipping</span>
                <span className="text-primary font-semibold">Free</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-on-surface-variant">Estimated Tax</span>
                <span className="font-semibold text-on-surface">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between pt-4 text-lg border-t border-dashed border-surface-container-high mt-2">
                <span className="font-headline-md text-base text-on-surface">Total</span>
                <span className="font-headline-md text-base text-primary">${total.toFixed(2)}</span>
              </div>
            </div>
          </div>

          <div className="bg-primary-container p-8 rounded-xl text-on-primary-container shadow-[0_10px_30px_rgba(124,58,237,0.15)]">
            <h3 className="font-headline-md text-xl mb-4 text-white">Need Help?</h3>
            <p className="font-body-md text-sm mb-6 text-white/90">Our concierge service is available 24/7 for any questions regarding your delivery.</p>
            <button className="w-full bg-white text-primary font-button py-4 rounded-lg flex items-center justify-center gap-2 hover:bg-surface-container-lowest transition-colors shadow-sm">
              <MessageSquare size={18} />
              Live Chat Support
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}
