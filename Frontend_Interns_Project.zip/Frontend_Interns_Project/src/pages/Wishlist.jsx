import { ShoppingBag, Trash2, X, Plus, Heart } from 'lucide-react';
import { Link } from 'react-router-dom';

const wishlistItems = [
  {
    id: 1,
    type: 'featured',
    name: "Sculptural Silk Midi Dress",
    collection: "Premium Collection",
    description: "A masterpiece of tailoring, featuring organic folds and a luminous lavender finish that captures the light from every angle.",
    price: 495.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDvUNi4LJVXwnPjF82ut9wVsPeBW10jooTDGqx1Sp0jACsOXajXohed8dUbV1T4DHacOs1bWqiYnsnOrUw1IMhJ8Yv2sk-5lbd70AvpI1tHmGnxkQUjOfq57fFl8Efv9H9HY05YNRVde11Jz7XYUx5mzOZ1_39lPtGfm6dsCL-nEbbRfKru0rliDNTwZw_3cSbXCiOzaKA3P4o2XepnQvh3a-MskpswiCDkRcbSJ1ib5maKFj5UdKYoS7zk00QzBfbGg25_ZO2doxYS"
  },
  {
    id: 2,
    type: 'regular',
    name: "Architectural Handle Bag",
    details: "Ivory Italian Leather",
    price: 320.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuD3CdAyGPEYwDQBD1z-BhyylwFI3-UCKSSy6g8eiQCWB13I1U-So2sMVnn7WzrVoWJeL2VF7D6H_98dcdi_NhuPpqZd_Y9vAEIhnFDvrqLi9i2wUU9z51JTH_OV5fS4N6Xv6m_GkA4GakxrpLZ1o4Gfbmy_cYqj0BxG_NaCCte60Gr5he8UrfCQbmsmFzzLQS4AAQSFaz0qyIlXzCHZgvX4BNot6_4qyZQTaiPH1ZdCsgGHHCfpc_4gaLm4RTI8K9H8sXVamVvUp4Vf"
  },
  {
    id: 3,
    type: 'regular',
    name: "Cashmere Overcoat",
    details: "Sand / Limited Edition",
    price: 850.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCjlQ7KhdYc0215rEFB039A_Wb8_rf64ej5acihLDzWwnPXAptR0TuDQI_Kuske9mSYT6n6TMjaNViUKdmJ3UtmNLeoNjTUookW-6SVxL5rGPShKZZyQonIBazCmbQocwU8ewl8Y41lHR7LLvtPuyo0Jdbf_zsMhec2kb7WWUqCfHQXTerXj4TL8-VLq72vp3Vc0OKXpXDkI-_CDusYYy2z-Blwn4gAK3kGIP0HZljoismo99l3c1OrjTiiOxQ7xmtwDBF_Vt0f6vng"
  },
  {
    id: 4,
    type: 'regular',
    name: "Strap Heel Sandal",
    details: "Nude / 85mm Heel",
    price: 210.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBKVlVBlgqH36Zs5ct7Tpp80yh38kQfhuJntMJh0oXwd9JCtAD5w3390Ck2HLpPR035HWb3cxu1uFl8PSJMpJi6Rk4_J_g2JrzThMxSGzelW4fIeyDBk1ZefV2Wx-AA0Qfk4BiP5QvKZDsHzIfcYefRpYqN1ayuj_B6_nMGe6kTOOtAwdsM-DU-h1GhsJQrFZRtJPMieKUvSSxQbMzOtIMQKEtAZzYudBY0scaeuGsR5cV4PS736vtuOrMVRZYWf-CYr9ximRSNSrXT"
  }
];

const recommendedItems = [
  {
    id: 101,
    name: "Infinity Pearl Pendant",
    price: 185.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAyU8VXVuxkktTDmWRpz3fur4OhXh5QSn_KD_JLn2QynLNvHIgaN2T0d0D0rqieadhtZ33xIzoPu5rafLkvNC29KeApJYb0Dbmnsr_W2oIWjSrlMDSmtP4Fc2ZzSZJomyhC_jUymIxAbl1Bt43csPSHLp1BIFCjtn1ytD5_3AfLth8Tjryd4aXVDnq54BfjGp1eBe3gjc9bvMa2c21i419NKtLrec1wmJj-gFP8DW5ceW6V2ikyXlA-IF8vhUTp5Dg3ff9ztChYIq4w"
  },
  {
    id: 102,
    name: "Aviator Eclipse Glasses",
    price: 240.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCDhFfyNj_RxIberFPFU0EVjyqM9jfyQE_MFjUlgsIqUTd0yBqf6TQrVse5lv5YcE31T4AYZvIWAlTsn74y5ZMYSETQu6q2VFpc8B1QsoNFBe46Fa9G5AOYv5FS-iB4trrUv-zDevsV7vm694AZ0FYrEpEBIuK3aHFKR1hRN-uOS_1eqY1DQaj-H9NTYSnprAzFDaAKD2I9mIqixVSjDLXOWm7ewlNe0VAbemd86n4-YCmIPRrazEEtd1hoQxX_GC-SjvFylJ3oP2QJ"
  },
  {
    id: 103,
    name: "Cloud Walk Trainers",
    price: 380.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBvn_LlmeExLSpnGUX8V9_tpBTOywAlzk0NAdCqAAbQorOn7xrdUI2zYRlGAD3RUMdMq_eApPfJVKglub6y0TBO2b9q8k0wvOCY73Im0oiasqZhSx1H0QRSxtMG6cCKxsrLI2IrvKVou3fYiO02VQufslqdnehdR1aM65o-_Eyt6SHFT1_N-2s63STysFJm4i0CqnRDLqctV_Q7pP3BHCGXPpWWNa26A2CzppUuLsBeL_MS3AhTQYzTIk-FviQiRKGNhP2OYymLzUb7"
  },
  {
    id: 104,
    name: "Botanical Silk Scarf",
    price: 115.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuB6Dx0qCXTbRudtG1bhd2ShSFbo-Ef9ydgQwvGdTEOu3iNYafNAhkiOHPbkv7B_cNQPanXZ3VbmtAx3xEWmWRT3jCDDUYi8heUPQFWpYtBJt7HOCH6Vj5CWgnqZdvCUBMcRyjCpXsEJFMd5ZW-_fKerXb5KDWJ5c9p4iUAPDco5cwXepcdzgc3fZ1Gwn8kZVwcPRYM4IW8nEgmxpyBiHPShM79eSjlc7EKt5oVEzsJW2lNAIyhvB5W8cHdG88mx-wCefWBLPFJ4Hcl1"
  }
];

export default function Wishlist() {
  return (
    <div className="pt-12 pb-32 max-w-7xl mx-auto px-8">
      {/* Page Header */}
      <div className="mb-12">
        <h1 className="font-headline-lg text-5xl text-on-surface mb-2">Your Wishlist</h1>
        <p className="font-body-lg text-lg text-on-surface-variant max-w-2xl">Curated treasures waiting for a permanent home in your wardrobe. Move them to your bag when you're ready to make them yours.</p>
      </div>

      {/* Wishlist Content: Bento Grid Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        
        {/* Item 1: Large Featured Card */}
        {wishlistItems.filter(item => item.type === 'featured').map(item => (
          <div key={item.id} className="md:col-span-8 group relative bg-surface-container-lowest rounded-xl overflow-hidden shadow-[0_20px_40px_rgba(124,58,237,0.04)] hover:shadow-[0_20px_40px_rgba(124,58,237,0.08)] transition-all duration-500">
            <div className="grid md:grid-cols-2 h-full">
              <div className="relative overflow-hidden aspect-[4/5] md:aspect-auto">
                <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src={item.image} alt={item.name} />
              </div>
              <div className="p-12 flex flex-col justify-between">
                <div>
                  <span className="font-label-md text-sm text-primary uppercase tracking-widest mb-2 block">{item.collection}</span>
                  <h3 className="font-headline-md text-3xl text-on-surface mb-4">{item.name}</h3>
                  <p className="font-body-md text-base text-on-surface-variant mb-6">{item.description}</p>
                  <p className="font-headline-md text-3xl text-primary">${item.price.toFixed(2)}</p>
                </div>
                <div className="flex flex-col gap-4 mt-8">
                  <button className="w-full py-4 px-8 bg-primary text-white font-button text-base rounded-lg hover:bg-primary/90 active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                    <ShoppingBag size={18} />
                    Move to Bag
                  </button>
                  <button className="w-full py-4 px-8 bg-surface-container text-on-surface-variant font-button text-base rounded-lg hover:bg-surface-container-high active:scale-[0.98] transition-all flex items-center justify-center gap-2">
                    <Trash2 size={18} />
                    Remove Item
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}

        {/* Regular Grid Items */}
        {wishlistItems.filter(item => item.type === 'regular').map(item => (
          <div key={item.id} className="md:col-span-4 group bg-surface-container-lowest rounded-xl overflow-hidden shadow-[0_20px_40px_rgba(124,58,237,0.04)] hover:shadow-[0_20px_40px_rgba(124,58,237,0.08)] transition-all duration-500">
            <div className="relative aspect-[3/4] overflow-hidden">
              <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src={item.image} alt={item.name} />
              <button className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center text-error hover:bg-error-container transition-colors shadow-sm">
                <X size={20} />
              </button>
            </div>
            <div className="p-6">
              <h3 className="font-headline-md text-xl mb-2 leading-tight text-on-surface">{item.name}</h3>
              <p className="font-body-md text-base text-on-surface-variant mb-4">{item.details}</p>
              <div className="flex items-center justify-between">
                <span className="font-headline-md text-2xl text-primary">${item.price.toFixed(2)}</span>
                <button className="w-12 h-12 bg-primary text-white rounded-full flex items-center justify-center hover:bg-primary/90 active:scale-[0.98] transition-all">
                  <ShoppingBag size={20} />
                </button>
              </div>
            </div>
          </div>
        ))}

        {/* Empty Slot / Suggestion Card */}
        <div className="md:col-span-4 flex flex-col items-center justify-center border-2 border-dashed border-outline-variant rounded-xl p-8 text-center bg-surface-container-low/30 group hover:border-primary transition-colors min-h-[400px]">
          <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center text-primary mb-6 group-hover:scale-110 transition-transform">
            <Plus size={32} />
          </div>
          <h4 className="font-headline-md text-xl mb-2 text-on-surface">Discover More</h4>
          <p className="font-body-md text-base text-on-surface-variant mb-6 max-w-[200px]">Found something else you love? Browse our new arrivals.</p>
          <Link to="/products" className="font-button text-base text-primary border-b border-primary pb-1 hover:text-primary/80 hover:border-primary/80 transition-colors">
            Explore Collections
          </Link>
        </div>
      </div>

      {/* Recommendations Section */}
      <section className="mt-32">
        <div className="flex justify-between items-end mb-12">
          <div>
            <h2 className="font-headline-md text-3xl text-on-surface mb-2">Complete the Look</h2>
            <p className="font-body-md text-base text-on-surface-variant">Selected specifically to match your wishlist style.</p>
          </div>
          <Link to="/products" className="font-label-md text-sm text-primary uppercase tracking-widest border-b border-primary/20 pb-1 hover:border-primary transition-colors">
            View All
          </Link>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {recommendedItems.map(item => (
            <div key={item.id} className="group">
              <div className="relative aspect-square overflow-hidden rounded-xl mb-4">
                <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src={item.image} alt={item.name} />
                <div className="absolute bottom-4 right-4 translate-y-8 opacity-0 group-hover:translate-y-0 group-hover:opacity-100 transition-all duration-300">
                  <button className="w-10 h-10 bg-white shadow-xl rounded-full flex items-center justify-center text-primary hover:bg-primary hover:text-white transition-colors">
                    <Heart size={20} />
                  </button>
                </div>
              </div>
              <h4 className="font-label-md text-sm text-on-surface">{item.name}</h4>
              <p className="font-body-md text-sm text-on-surface-variant mt-1">${item.price.toFixed(2)}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
