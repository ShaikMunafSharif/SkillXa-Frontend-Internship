export default function Dashboard() { return <div className='p-24 text-center'><h1 className='text-4xl font-headline-lg'>{}</h1></div>; }
