import { Lock, CreditCard, Wallet, ShieldCheck } from 'lucide-react';

const checkoutItems = [
  {
    id: 1,
    name: "Atelier Trench Coat",
    details: "Size: Medium / Sand",
    price: 450.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBgIBDQDHTkHGit_nUn0Y0DGwEaIYyAN9MmchSZ-3SaX11UHn5ql6T41Oo1h2pHQw4vuxRsK6P1hZjKh3w8Wj-rprAtTTxng8y2q-YsF29Vf0EiLEqUKYoqFCmr8hQN0Cz8pwrR71-GeSwnkWDw4Jwh5eMzkbvbjNVh2xC6xeZ6B2_Qx-AO3ctd1S2L4I8qGjqTbdIgxy1WXvUQclTzpRHAjkm9zkbYCYOnQlmUk_ibX3AFihBTNUxdi5n6Xza37yI4U6GTql8ZSjNz"
  },
  {
    id: 2,
    name: "Lunar Loafers",
    details: "Size: 42 / Onyx",
    price: 280.00,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuC7tjmx5IE3IbRgi9Df1x6I6uZISsJJcue20Mmfx3UGCN2iXMnkX7QGVTbqUbaV7Q6VYKYIKRNhwsKNe5ur336Ry9tIvceFcsuAsBkdOvJ0BIERLxxW_vOf-d_UlZIa4GKKMFA-kY2nULOlbgAWtJim70ot-YDkGkIWEleUy9VLiucuM3sHZt6lCb6ECC71E2ZI3pawm9L_SZFQor4Gk8l7sQdX-dNYrZkshV-kxBx8yGBbOG_mhMAXGe6dQ3Tu6zGjLsuff-JN0pk_"
  }
];

export default function Checkout() {
  const subtotal = checkoutItems.reduce((sum, item) => sum + item.price, 0);
  const tax = subtotal * 0.08;
  const total = subtotal + tax;

  return (
    <>
      {/* Simplified Header for Transactional Flow */}
      <header className="bg-surface/80 backdrop-blur-xl fixed top-0 w-full z-50 transition-colors duration-500">
        <div className="flex justify-between items-center max-w-7xl mx-auto px-8 h-20">
          <span className="text-2xl font-black tracking-tighter text-violet-600">AURA</span>
          <div className="flex items-center gap-2 text-slate-400 font-label-md uppercase text-xs">
            <Lock size={14} />
            <span>Secure Checkout</span>
          </div>
          <div className="w-10"></div> {/* Spacer for balance */}
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-8 pt-32 pb-32 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Multi-step Form Section */}
        <div className="lg:col-span-8 space-y-12">
          {/* Step Header */}
          <div className="flex items-center gap-8 border-b border-surface-container pb-6">
            <div className="flex items-center gap-3">
              <span className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center font-bold text-sm">1</span>
              <span className="font-headline-md text-3xl">Shipping</span>
            </div>
            <div className="h-px bg-surface-container flex-grow"></div>
            <div className="flex items-center gap-3 opacity-40">
              <span className="w-8 h-8 rounded-full bg-surface-variant text-on-surface-variant flex items-center justify-center font-bold text-sm">2</span>
              <span className="font-headline-md text-3xl">Payment</span>
            </div>
          </div>

          {/* Address Form */}
          <section className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="block font-label-md text-sm text-on-surface-variant">First Name</label>
                <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all" placeholder="Julian" type="text" />
              </div>
              <div className="space-y-2">
                <label className="block font-label-md text-sm text-on-surface-variant">Last Name</label>
                <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all" placeholder="Sterling" type="text" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="block font-label-md text-sm text-on-surface-variant">Shipping Address</label>
              <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all" placeholder="245 Boutique Avenue, Suite 400" type="text" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-2">
                <label className="block font-label-md text-sm text-on-surface-variant">City</label>
                <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all" placeholder="New York" type="text" />
              </div>
              <div className="space-y-2">
                <label className="block font-label-md text-sm text-on-surface-variant">State</label>
                <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all" placeholder="NY" type="text" />
              </div>
              <div className="space-y-2">
                <label className="block font-label-md text-sm text-on-surface-variant">ZIP Code</label>
                <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all" placeholder="10001" type="text" />
              </div>
            </div>
            <div className="flex items-center gap-3 pt-3">
              <input className="rounded border-surface-variant text-primary focus:ring-primary w-5 h-5" id="save-address" type="checkbox" />
              <label className="font-body-md text-on-surface-variant" htmlFor="save-address">Save this address to my profile for future purchases</label>
            </div>
          </section>

          {/* Payment Options Section */}
          <section className="pt-12 space-y-6">
            <h3 className="font-headline-md text-3xl">Payment Method</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Card Option */}
              <div className="group cursor-pointer border-2 border-primary rounded-xl p-6 bg-surface-container-low transition-all hover:bg-white shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
                <div className="flex justify-between items-start mb-6">
                  <CreditCard className="text-primary" size={32} />
                  <div className="w-5 h-5 rounded-full border-2 border-primary flex items-center justify-center">
                    <div className="w-2.5 h-2.5 bg-primary rounded-full"></div>
                  </div>
                </div>
                <p className="font-label-md text-sm uppercase tracking-widest text-on-surface-variant mb-1">Credit / Debit Card</p>
                <p className="font-body-md text-sm text-slate-500">Secure encryption provided by Stripe</p>
              </div>

              {/* Digital Wallet Option */}
              <div className="group cursor-pointer border-2 border-transparent rounded-xl p-6 bg-surface-container-low transition-all hover:border-primary-fixed-dim hover:bg-white">
                <div className="flex justify-between items-start mb-6">
                  <Wallet className="text-slate-400" size={32} />
                  <div className="w-5 h-5 rounded-full border-2 border-surface-variant"></div>
                </div>
                <p className="font-label-md text-sm uppercase tracking-widest text-on-surface-variant mb-1">Digital Wallet</p>
                <p className="font-body-md text-sm text-slate-500">Apple Pay, Google Pay, or PayPal</p>
              </div>
            </div>

            {/* Inline Card Details */}
            <div className="bg-white rounded-xl p-8 border border-surface-container space-y-6 shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
              <div className="space-y-2">
                <label className="block font-label-md text-sm text-on-surface-variant">Card Number</label>
                <div className="relative">
                  <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all pl-12" placeholder="0000 0000 0000 0000" type="text" />
                  <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="block font-label-md text-sm text-on-surface-variant">Expiry Date</label>
                  <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all" placeholder="MM / YY" type="text" />
                </div>
                <div className="space-y-2">
                  <label className="block font-label-md text-sm text-on-surface-variant">CVC</label>
                  <input className="w-full bg-surface-container-low border-none rounded-lg p-4 font-body-md focus:outline-none focus:ring-0 focus:border-b-2 focus:border-b-primary shadow-sm transition-all" placeholder="123" type="text" />
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* Sidebar / Order Summary */}
        <aside className="lg:col-span-4 lg:sticky lg:top-32 h-fit">
          <div className="bg-white rounded-2xl p-8 border border-surface-container space-y-6 shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <h3 className="font-headline-md text-2xl text-on-surface">Order Summary</h3>
            
            {/* Product List */}
            <div className="space-y-6">
              {checkoutItems.map(item => (
                <div key={item.id} className="flex gap-4">
                  <div className="w-20 h-24 bg-surface-container-low rounded-lg overflow-hidden flex-shrink-0">
                    <img className="w-full h-full object-cover" src={item.image} alt={item.name} />
                  </div>
                  <div className="flex flex-col justify-center">
                    <h4 className="font-button text-on-surface">{item.name}</h4>
                    <p className="text-sm text-slate-500 font-body-md mt-1">{item.details}</p>
                    <p className="text-sm font-bold text-primary mt-1">${item.price.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="border-t border-surface-container pt-6 space-y-3">
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-body-md">Subtotal</span>
                <span className="font-button text-on-surface">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-body-md">Shipping</span>
                <span className="font-button text-green-600">Free</span>
              </div>
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-body-md">Estimated Tax</span>
                <span className="font-button text-on-surface">${tax.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between text-on-surface pt-3 text-xl border-t border-dashed border-surface-container mt-2">
                <span className="font-headline-md">Total</span>
                <span className="font-headline-md text-primary">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Promo Code */}
            <div className="pt-3">
              <div className="flex gap-2">
                <input className="flex-grow bg-surface-container-low border-none rounded-lg p-3 text-sm font-body-md focus:ring-2 focus:ring-primary outline-none" placeholder="Promo Code" type="text" />
                <button className="bg-surface-container-highest text-on-surface px-4 py-2 rounded-lg font-button text-sm hover:bg-surface-variant transition-colors">Apply</button>
              </div>
            </div>

            {/* CTA Button */}
            <button className="w-full bg-primary-container text-white py-5 rounded-xl font-button text-lg tracking-wide shadow-xl shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all mt-4">
              Complete Purchase
            </button>
            
            <div className="flex items-center justify-center gap-2 text-slate-400 pt-4">
              <ShieldCheck size={16} />
              <span className="text-[10px] uppercase tracking-widest font-label-md">30-Day Easy Returns</span>
            </div>
          </div>
        </aside>
      </div>

      {/* Simplified Footer for Transactional Flow */}
      <footer className="w-full border-t border-slate-100 bg-slate-50">
        <div className="flex flex-col md:flex-row justify-between items-center py-16 px-8 max-w-7xl mx-auto gap-8">
          <div className="text-xl font-bold text-violet-600">AURA</div>
          <p className="font-epilogue text-xs tracking-widest uppercase text-slate-400">© 2024 AURA Boutique. Designed for the discerning.</p>
          <div className="flex gap-8">
            <a className="font-epilogue text-xs tracking-widest uppercase text-slate-400 hover:text-violet-600 transition-colors" href="#">Privacy Policy</a>
            <a className="font-epilogue text-xs tracking-widest uppercase text-slate-400 hover:text-violet-600 transition-colors" href="#">Contact Us</a>
          </div>
        </div>
      </footer>
    </>
  );
}
