import { Link } from 'react-router-dom';
import { Truck } from 'lucide-react';

const dealProducts = [
  {
    id: 1,
    category: "Footwear",
    name: "The Minimalist Runner",
    price: "$168.00",
    originalPrice: "$240.00",
    discount: "-30%",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDpAyvL1v-gSourr57Qy5hb2_ii2n7sVvHsAncyxFKgmw2I9JxxW5SZ9A5nO-hfMyValyUi35GIaJ3fhQMCNQ10tsS_UB2GgEAHTi-BW10rqkf_JzY_wn1QCmWtiJQUhXi1Hk0wntuB6NFWJByT3d5Wo6xmy-GpqwzNCmTPzVkuUlxrubDEJkmfziudY4nNIqLeLX1olW0NZz459UI9MJzOjgKyBmcS4fLPiZRkpllbqkvQJ3T0h5hdbNMMiHIkOTRPE70_MAOwzb6-",
  },
  {
    id: 2,
    category: "Outerwear",
    name: "Structured Wool Overcoat",
    price: "$324.00",
    originalPrice: "$540.00",
    discount: "-40%",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuD11AuE2hPC_QLTrNdmpfyxv0Dam_5VulznzpA3bPM5Sq0u-JP4Hlwv_Q351grBHazcbGe8UQL90usHX-dMjnicuNzqdWWy9h0rua8IFoGYu-QoKqLcoO38cdFHGxL1SaMi68etkOp6P9VMGXdHUT2e2Sf37N1gHj84kRa7QfBOYFTsa8eSzcrmQPG1Er7EslnnVgWNRgicpR2ppTpwI3SFVPxUBYcsNmV6dUqzk47VKaDOPESCBjWQuz2FmcN9YFptluELtR5iwYbn",
  },
  {
    id: 3,
    category: "Essentials",
    name: "Silk Satin Shirt",
    price: "$135.00",
    originalPrice: "$180.00",
    discount: "-25%",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBtlk8mM-NIYjLXTZYtx5_zbxAEXfEeua7EUdphLV7i7jsOi00F9g9CbgXwsfq7xsW0WXbxeG609qcRwvF-XdmCxRqpj7CwMWIZFpBfUnmDQT3SIgi1NKo3jWM7kmoaRGeMVUdUBcf3yG2bE4TSAgYQ1y1WAbshB8zt3sLjBlIbYAa3xcDwsE1_3aib5ILgl7ScmZgo-PsYxx0r0PDD9sft1B7EtvauBOtMg9ZSZn-vP2LqYmWDoLaAsITiHPeRlb35Z6iivcKu-DbM",
  }
];

export default function Deals() {
  return (
    <>
      {/* Hero Section: Major Deal */}
      <section className="relative w-full h-[819px] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img className="w-full h-full object-cover brightness-75" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDcUUj3oc4mZyGl4nBuZy17Eo-0RyV4q7tZ9vfOnoGMO7Y3N3R3d915rPTF_miheoJ6TJnbNs0LE_SQxiI4mi62fYxLG361IDD2aGLGBp3bM5UejhTOAYjeuYxt5j-6co5qAKPR27vfTB4yswrMMKeV6sKYUkNHaZBA_UiVSwRe56BtBEFs013SkP9fA0OB3AE1K5iYi6t2eKUHmZXb7eOvVtfTUIFutEPUqV35yYJTGQRTyoo8Oj-yQy78Or6XLd4lto0XvhvtgCb3" alt="Background" />
        </div>
        <div className="relative z-10 text-center px-8 max-w-4xl">
          <span className="font-label-md text-on-primary-container bg-primary-container px-4 py-2 rounded-full inline-block mb-6 uppercase tracking-widest text-sm">Limited Time Event</span>
          <h1 className="font-display-xl text-white mb-6 text-7xl md:text-8xl">The Curator's Sale</h1>
          <p className="font-body-lg text-white/90 mb-10 max-w-2xl mx-auto text-lg">Elevate your collection with up to 40% off seasonal essentials. A focused curation of our most sought-after pieces.</p>
          
          {/* Countdown Timer */}
          <div className="flex justify-center gap-8 mb-12">
            <div className="flex flex-col items-center">
              <span className="font-headline-lg text-white text-5xl">02</span>
              <span className="font-label-md text-white/70 uppercase text-xs tracking-wider mt-2">Days</span>
            </div>
            <div className="font-headline-lg text-white self-start text-4xl">:</div>
            <div className="flex flex-col items-center">
              <span className="font-headline-lg text-white text-5xl">14</span>
              <span className="font-label-md text-white/70 uppercase text-xs tracking-wider mt-2">Hours</span>
            </div>
            <div className="font-headline-lg text-white self-start text-4xl">:</div>
            <div className="flex flex-col items-center">
              <span className="font-headline-lg text-white text-5xl">35</span>
              <span className="font-label-md text-white/70 uppercase text-xs tracking-wider mt-2">Mins</span>
            </div>
          </div>
          
          <button className="bg-primary hover:bg-primary-container text-on-primary font-button px-12 py-5 rounded-lg transition-all transform active:scale-95 shadow-xl text-lg">
            Explore the Sale
          </button>
        </div>
      </section>

      {/* Bento Grid: Featured Categories */}
      <section className="max-w-7xl mx-auto px-8 py-32">
        <div className="grid grid-cols-1 md:grid-cols-4 grid-rows-[auto] md:grid-rows-2 gap-8 h-auto md:h-[800px]">
          {/* Large Feature */}
          <div className="md:col-span-2 md:row-span-2 relative group overflow-hidden rounded-xl bg-surface-container shadow-[0_20px_40px_rgba(124,58,237,0.04)] aspect-square md:aspect-auto">
            <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuA-2ZN6gUO7RyYYNk6lo_WLhGamOMvK0HJkQ4L7lGJmPD5AX2tfv2NJUVIIyXyRDpQC8j68fvy0TXnwdzlYeMaC5He5lqcaisZNZ7Ljm5Ei4ScyACYXQr4GnxG2qjni7ZQ2uOJskbpwcfcgcxFyQP_fLM6uT5ZvLqyKLNgtLa8-kIjXXyar9F53mQ_41ebA7Jwx1hHHyIIDiyFEl22LBTGJXCHfp4cpj74tcO_jOTKtK5CiqoTmXPJ5aR25Z7VvbFtmXd5WVtSL1AdP" alt="Accessories" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex flex-col justify-end p-10">
              <h3 className="font-headline-lg text-white mb-2 text-4xl">Accessories</h3>
              <p className="font-body-md text-white/80 mb-6 text-lg">Extra 15% off with code AURA15</p>
              <button className="bg-white text-on-surface font-button px-8 py-4 rounded-lg self-start hover:bg-surface-container transition-colors">Shop Now</button>
            </div>
          </div>
          
          {/* Medium Feature 1 */}
          <div className="md:col-span-2 relative group overflow-hidden rounded-xl bg-surface-container shadow-[0_20px_40px_rgba(124,58,237,0.04)] aspect-[2/1] md:aspect-auto">
            <img className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuD2yOxKavZqK5Pd4AKRNxCPXSS6qYJF5YJPNpHop0zNcoBxMcQ6wIxvwqYs1tr5_0pu6x8hX8WA2fTBTfb9VeMM5k4xGwDIDIm1sfYypxvae5ERyYe225xQB2RLsBpXBgtlxirJ7WJELp5EqXDBjS7xuTquKQt2-VXsGkne2wMK-5UeqqJPn7yVufwCFGj8nIwXy5jbsjaSHomge__aH6V9XvmAyshfjz_pKb7SKMk0rHXgwzu3mWS6SoT6Gi5IEUUgYcph65Zwv2BR" alt="Pre-Sale" />
            <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors"></div>
            <div className="absolute inset-0 flex flex-col justify-center items-center text-center p-8">
              <span className="font-label-md text-white uppercase tracking-widest mb-2 text-xs">Member Exclusive</span>
              <h3 className="font-headline-md text-white mb-4 text-3xl">First Look: Summer Pre-Sale</h3>
              <Link to="/signup" className="text-white border-b border-white pb-1 font-button hover:text-primary hover:border-primary transition-colors">Join the Circle</Link>
            </div>
          </div>
          
          {/* Small Feature 1 */}
          <div className="md:col-span-1 relative group overflow-hidden rounded-xl bg-surface-container shadow-[0_20px_40px_rgba(124,58,237,0.04)] aspect-square md:aspect-auto">
            <div className="absolute inset-0 bg-violet-600 flex flex-col justify-center p-8">
              <Truck className="text-white mb-4" size={40} />
              <h4 className="font-headline-md text-2xl text-white mb-2 leading-tight">Complimentary Shipping</h4>
              <p className="font-body-md text-white/80">On all orders over $150 this weekend.</p>
            </div>
          </div>
          
          {/* Small Feature 2 */}
          <div className="md:col-span-1 relative group overflow-hidden rounded-xl bg-surface-container shadow-[0_20px_40px_rgba(124,58,237,0.04)] aspect-square md:aspect-auto">
            <img className="w-full h-full object-cover opacity-80 transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAtzz-BublhOaek121BzGYzvARPbXnJDoUH5No73AXsA5qvayZYF4TZbGPpjHlmalGcOw4c6-lhN__GK2HG-zFbCf9uQPUN9grL60JzMl6Tcz2vJmsTXlbq1MjrGIoPEPF61uEJFkH9wo4MR4NOpGMcRRODyDJkaWLxwbzQvf0Jb5vNQ0iAdnZLiJrpJt_iOnwG1NO10pRZmprPIpyZ-fbrGjd50hXMb9mcYNUp-UzTcbePddys_4JvPLT4oAntSxOd2V5E0-_fWTwn" alt="Last Call" />
            <div className="absolute inset-0 flex items-end p-6">
              <span className="font-headline-md text-white text-2xl leading-tight">Last Call <br/>Items</span>
            </div>
          </div>
        </div>
      </section>

      {/* Highlight Section: The Deal List */}
      <section className="bg-surface-container-low py-32">
        <div className="max-w-7xl mx-auto px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-8">
            <div>
              <span className="font-label-md text-primary uppercase tracking-widest mb-4 block text-sm">Refined Selection</span>
              <h2 className="font-headline-lg text-5xl">Discerning Discounts</h2>
            </div>
            <div className="flex flex-wrap gap-4">
              <button className="px-6 py-2 rounded-full border border-outline-variant bg-white text-on-surface font-label-md hover:bg-primary hover:text-white transition-colors">All Deals</button>
              <button className="px-6 py-2 rounded-full border border-outline-variant bg-white text-on-surface font-label-md hover:bg-primary hover:text-white transition-colors">Women</button>
              <button className="px-6 py-2 rounded-full border border-outline-variant bg-white text-on-surface font-label-md hover:bg-primary hover:text-white transition-colors">Men</button>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {dealProducts.map(product => (
              <div key={product.id} className="group">
                <div className="relative overflow-hidden rounded-xl bg-white mb-6">
                  <img className="w-full aspect-[4/5] object-cover transition-transform duration-500 group-hover:scale-105" src={product.image} alt={product.name} />
                  <div className="absolute top-4 left-4 bg-error text-white font-label-md px-3 py-1 rounded text-sm">{product.discount}</div>
                  <button className="absolute bottom-6 left-1/2 -translate-x-1/2 bg-white/90 backdrop-blur-md text-on-surface font-button px-8 py-4 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:text-primary">Quick Add</button>
                </div>
                <div className="space-y-1">
                  <p className="font-label-md text-slate-400 uppercase text-xs tracking-wider">{product.category}</p>
                  <h4 className="font-headline-md text-xl">{product.name}</h4>
                  <div className="flex gap-3 items-center">
                    <span className="font-body-lg text-error font-bold">{product.price}</span>
                    <span className="font-body-md text-slate-400 line-through">{product.originalPrice}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Newsletter / CTA */}
      <section className="max-w-7xl mx-auto px-8 py-32">
        <div className="relative bg-primary-container rounded-2xl p-16 overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full opacity-20">
            <img className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuDCnVB_riN55Yth_NPh-4fnxWo18ZmN1Y0vXhx3twsY_ltSb5BRZVtcF2hTWkCBZ2sMBfOGXMfOK9XM5Xzc-M-JWqPJbrRBLA3Y31pPkjNjdloxPAUCigA5yVnh5Fpe4b-ZfTgwrufgn41UreaSjEbfBmYMM1_DihPMWNGZB5GPfs8y38k4ycXZ1iownQZLmvhLX5vjg1ScoeDtsVJP0bwUj2-VFianGwqwfWN2yyA2bMKTwkgEtMhrtzVtGviYGi_79Ljsh-qam8Hs" alt="Texture" />
          </div>
          <div className="relative z-10 max-w-xl">
            <h2 className="font-headline-lg text-white mb-6 text-5xl">Never Miss a Moment.</h2>
            <p className="font-body-lg text-white/80 mb-10 text-lg">Sign up for our AURA Insider list to receive early access to seasonal sales, limited edition collaborations, and a 10% discount on your first order.</p>
            <form className="flex flex-col sm:flex-row gap-4" onSubmit={e => e.preventDefault()}>
              <input className="flex-grow bg-white/10 border-0 focus:ring-2 focus:ring-white text-white placeholder-white/60 px-6 py-4 rounded-lg backdrop-blur-md outline-none" placeholder="Your email address" type="email" />
              <button className="bg-white text-primary font-button px-10 py-4 rounded-lg hover:bg-slate-100 transition-all text-lg" type="submit">Subscribe</button>
            </form>
          </div>
        </div>
      </section>
    </>
  );
}
