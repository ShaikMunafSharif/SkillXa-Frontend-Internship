import { ChevronRight, Minus, Plus, Heart, Trash2, Truck, Lock, CreditCard, Wallet, Gift } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState } from 'react';

const initialCartItems = [
  {
    id: 1,
    collection: "Essential Collection",
    name: "Sculpted Linen Blazer",
    details: "Size: Medium | Color: Oat Milk",
    price: 420.00,
    quantity: 1,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDt4oFefbE0W9ScpNYqy9wgbt3PtDfOuEc8mIApRpDwEBDvuqbBkZFzyTjFQqDceOQVi9MIs8Re1Qb14siKjKLupj99uSNwKDXCki70GPxSvaAEf9m2WbXM7TUSrFUjfcqYYSNJgTvnugUWtE9Y8pfLLoIxBK_TOR2SB8HBzIRg3Ta-ipfF21A0kBCiiqTET_seI-4vMEPRpAJKF4dx9LdJ918P0Ji9CvDqZYUV79A0Aw10WbHBU326El58lmS93gUIpu5xBnSWyFXN"
  },
  {
    id: 2,
    collection: "Limited Edition",
    name: "Horizon Leather Bag",
    details: "Color: Midnight Charcoal",
    price: 890.00,
    quantity: 1,
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuB0jr3JR7vDD6nVGVj3pRoIxJlsfYEMI50vG3wu1z_O4IdkUYu-C-Iw21b2BP8WxhlM4f-DxDZdb2aYTihjPxkIEMhQBaxbumCDqZSPHj3y3xwM-RQX6lsFdDXpXJ482vaYe9Gne4oSK9apuI8i2S8wJFiIlk9l10lgeJaEfsBTEA1Kj-dXYz9u_S-B1bzHsvcHnQgNWkWu7uRqeOmyCwjtREAtZY6gVQvC9w-KWhOtvGym6lEYEfLdLEz1Ja3fW9k6DNK23BhQTvT1"
  }
];

export default function Cart() {
  const [cartItems, setCartItems] = useState(initialCartItems);

  const updateQuantity = (id, delta) => {
    setCartItems(items => items.map(item => {
      if (item.id === id) {
        const newQuantity = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQuantity };
      }
      return item;
    }));
  };

  const removeItem = (id) => {
    setCartItems(items => items.filter(item => item.id !== id));
  };

  const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const tax = subtotal * 0.0824; // Approximate based on $108 for $1310
  const total = subtotal + tax;

  return (
    <div className="py-12 px-8 max-w-7xl mx-auto">
      {/* Breadcrumb / Header */}
      <header className="mb-12">
        <div className="flex items-center gap-2 text-on-surface-variant font-label-md uppercase text-[10px] mb-4">
          <span>Shop</span>
          <ChevronRight size={14} />
          <span className="text-primary font-bold">Shopping Bag</span>
        </div>
        <h1 className="font-headline-lg text-5xl text-on-surface">Your Selection</h1>
      </header>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Product List */}
        <section className="flex-grow space-y-6 w-full lg:w-[calc(100%-432px)]">
          {cartItems.map(item => (
            <div key={item.id} className="flex gap-6 p-6 bg-surface-container-lowest rounded-xl shadow-[0_20px_40px_rgba(124,58,237,0.04)] group hover:shadow-[0_20px_40px_rgba(124,58,237,0.08)] transition-all duration-500">
              <div className="w-32 h-40 bg-surface-container rounded-lg overflow-hidden flex-shrink-0">
                <img className="w-full h-full object-cover" src={item.image} alt={item.name} />
              </div>
              <div className="flex-grow flex flex-col justify-between">
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-label-md text-primary text-[11px] uppercase mb-1">{item.collection}</p>
                    <h3 className="font-headline-md text-xl text-on-surface">{item.name}</h3>
                    <p className="font-body-md text-on-surface-variant mt-1">{item.details}</p>
                  </div>
                  <p className="font-headline-md text-xl text-on-surface">${item.price.toFixed(2)}</p>
                </div>

                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mt-4 gap-4">
                  <div className="flex items-center bg-surface-container-low rounded-full px-2 py-1">
                    <button onClick={() => updateQuantity(item.id, -1)} className="w-8 h-8 flex items-center justify-center hover:text-primary transition-colors text-on-surface">
                      <Minus size={16} />
                    </button>
                    <span className="w-10 text-center font-bold font-label-md text-on-surface">{String(item.quantity).padStart(2, '0')}</span>
                    <button onClick={() => updateQuantity(item.id, 1)} className="w-8 h-8 flex items-center justify-center hover:text-primary transition-colors text-on-surface">
                      <Plus size={16} />
                    </button>
                  </div>

                  <div className="flex gap-4">
                    <button className="text-on-surface-variant hover:text-primary transition-colors flex items-center gap-1 font-label-md text-xs uppercase tracking-wider">
                      <Heart size={16} /> Save
                    </button>
                    <button onClick={() => removeItem(item.id)} className="text-on-surface-variant hover:text-error transition-colors flex items-center gap-1 font-label-md text-xs uppercase tracking-wider">
                      <Trash2 size={16} /> Remove
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Shipping Info Banner */}
          <div className="bg-surface-container-low p-6 rounded-xl flex items-center gap-4">
            <Truck className="text-primary flex-shrink-0" size={32} />
            <div>
              <p className="font-button text-sm text-on-surface">Complimentary Express Shipping</p>
              <p className="text-xs text-on-surface-variant mt-1">Your order qualifies for free 2-day delivery.</p>
            </div>
          </div>
        </section>

        {/* Order Summary */}
        <aside className="w-full lg:w-[400px] lg:sticky lg:top-32 flex-shrink-0">
          <div className="bg-surface-container-lowest p-8 rounded-xl shadow-[0_20px_40px_rgba(124,58,237,0.06)] border border-surface-variant">
            <h2 className="font-headline-md text-2xl mb-8 text-on-surface">Order Summary</h2>

            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-body-md">Subtotal</span>
                <span className="font-button text-on-surface">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-body-md">Shipping</span>
                <span className="font-button text-primary">Free</span>
              </div>
              <div className="flex justify-between text-on-surface-variant">
                <span className="font-body-md">Estimated Tax</span>
                <span className="font-button text-on-surface">${tax.toFixed(2)}</span>
              </div>

              <div className="pt-4 border-t border-surface-variant border-dashed">
                <div className="flex justify-between items-baseline">
                  <span className="font-headline-md text-xl text-on-surface">Total</span>
                  <span className="font-headline-md text-3xl text-primary">${total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Promo Code */}
            <div className="mb-8">
              <label className="block font-label-md text-[10px] uppercase mb-2 text-on-surface-variant">Promo Code</label>
              <div className="flex gap-2">
                <input className="flex-grow bg-surface-container-low border-none rounded-lg font-body-md px-4 focus:ring-2 focus:ring-primary h-12 outline-none text-on-surface" placeholder="Enter code" type="text" />
                <button className="bg-surface-container text-primary font-button px-6 rounded-lg hover:bg-primary/20 transition-colors h-12">Apply</button>
              </div>
            </div>

            <Link to="/checkout" className="w-full bg-primary-container text-on-primary py-5 rounded-full font-button text-lg flex items-center justify-center gap-2 hover:bg-primary active:scale-[0.98] transition-all shadow-lg shadow-primary/20">
              Checkout Securely <Lock size={20} />
            </Link>

            <div className="mt-8 flex flex-col items-center gap-4">
              <p className="text-[10px] font-label-md uppercase text-on-surface-variant">We Accept</p>
              <div className="flex gap-6 opacity-50 grayscale hover:grayscale-0 hover:opacity-100 transition-all duration-500 text-on-surface">
                <CreditCard size={28} />
                <Wallet size={28} />
                {/* <ContactlessPayment size={28} /> */}
              </div>
            </div>
          </div>

          {/* Gift Option */}
          <div className="mt-6 p-6 bg-primary/5 rounded-xl border border-primary/20 flex items-center gap-4 cursor-pointer hover:bg-primary/10 transition-colors group">
            <Gift className="text-primary flex-shrink-0" size={24} />
            <div className="flex-grow">
              <p className="font-button text-sm text-on-surface">Add Gift Packaging</p>
              <p className="text-[10px] uppercase tracking-widest text-primary font-bold mt-1">Complimentary</p>
            </div>
            <ChevronRight className="text-on-surface-variant group-hover:text-primary transition-colors" size={20} />
          </div>
        </aside>
      </div>
    </div>
  );
}
