import { Link } from 'react-router-dom';
import { ChevronRight, ShoppingCart, Heart, Leaf, Truck, ArrowRight, Plus } from 'lucide-react';
import { useState } from 'react';

const relatedProducts = [
  {
    id: 1,
    category: "Trousers",
    name: "Architectural Trouser",
    price: "$310",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDv02OteO6u_tX1Omk7tY7asC0MZrYm1kWm6OKP3hGMRVhIOSq9HVzGEbyrmz4Bel29FF6C_8ageko1j_oBj8GQEIr9Da0Iu2pJOB8_GfA2m4oEZwtFcVHgNCnikVy3TOVEVvt4cNfGNTVPww1AsxZBUsYioItiV-KGAe49wYYS76E56H6KSXz7AWNQU6NqboDv1mWTJRpX4IUUPkoM72HZG5OEK2247DdaNP-zRwJ0JHN48M5ljV0Vc8AoKRYK3JeFCc6YF0oaroMO"
  },
  {
    id: 2,
    category: "Footwear",
    name: "Satin Pointed Heel",
    price: "$450",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBIHX3YkSIe0WeBtVhaqgHozqyxWJyrMD4wx_UwVojs_IX6QjP8xv7mPCSRo3X1T_1-SdAMTYsvQwZJnhoMxK50XDYUjHX4SkzoFBfO1P8cVuI19X8dn4hk-1giwEpiCzGbRMq0k98ARWocNNI_TYJuXNNO0wARUrIwYrHksiz3xfUcO2__KGX5sdMcVW_C9ruwfkCbNKjCmsE0r17Ednj9pSbYv3Q0yIa1GR5aDYqCHse9IIs4aQU7ENSemzATtNGrO1TaJV5LiL1O"
  },
  {
    id: 3,
    category: "Jewelry",
    name: "Cascade Gold Drop",
    price: "$120",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBzpw4E_NYmHAx4_p4kdOk6iqDBer5Eb5U6lw5Aw5QjLiAnwvg68EfxQHwo4sZKuYiptp2tHTmNL7HLOVTLUPsKxINE2qkxGOYuF2ksOIC6BDKBgFdFxXbCn7nSEdlLqttWjvCagshxDEnvggYqpwhJlY42eiKH9M7gB9TUXGDQmj3nezFNDH4w4fDeXMfC3viEeEy8uCGc1mhC6RimVTxhbouJcGMAWe8O65cQUwfJhZL7cZoT1jKqRyOYu5ZB3wJNu3pa6B6Ykxxu"
  },
  {
    id: 4,
    category: "Accessories",
    name: "AURA Leather Mini",
    price: "$590",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDm1BnV3Vdmg-dFUv-lfwMr-qW_oB-Y1ZXsqWlK6zOYmwo3GeTWo_V9oiT_feEgECfXagJVJIuzRieepk6JzTtvp0ERc2-ipoQhhmnyhug-QvYNYgg8LqSb8xlokss_tv88WcDbO9WFA9PDyCHA79pC7kyW2nGK2M6qEPEyZkShJxT-zm0GkT9crXj70h8tLIh-Og5TKT5nDp2gpSi7_sEKT_UKay7ghMFFk0do1CVnHOrbMT9msu0GN06sns9r5YGn0_V6mRjBNcVz"
  }
];

export default function ProductDetail() {
  const [activeTab, setActiveTab] = useState('description');
  const [selectedSize, setSelectedSize] = useState('S');

  return (
    <div className="py-12 px-8 max-w-7xl mx-auto">
      {/* Breadcrumbs */}
      <nav className="mb-12 flex items-center gap-2 text-on-surface-variant font-label-md uppercase tracking-widest text-xs">
        <Link to="/" className="hover:text-primary transition-colors">Home</Link>
        <ChevronRight size={12} />
        <Link to="/products" className="hover:text-primary transition-colors">Collections</Link>
        <ChevronRight size={12} />
        <span className="text-primary font-bold">Lumière Silk Blouse</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left: Product Gallery */}
        <div className="lg:col-span-7 grid grid-cols-2 gap-4">
          <div className="col-span-2 aspect-[4/5] bg-surface-container-low overflow-hidden rounded-xl group shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <img alt="Product main view" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCxvR5rtWuvfOX4g_uis08JTpci2haFytVsw1NbtE68GNsxECF11m5Jb-DZ7kLMAdeR2RdQyiCqngiefWPCumem_TVP_1bG2qm54WjtfkDIGt1B-TbWKg8fDGC2Zn3G3Ss7R2yQfa-dFaS2eMC06CF876xAh14u2SV1_HkAo5tR483siBcVxe0i89VzRH8yZ461wX8Uk_oQyB7sZglsWTmBHLKrd4vDCXLmzDJ2QoXtAC4_Q5T2UJFMldotUklZRWkNAqXrFS1GVH50" />
          </div>
          <div className="aspect-square bg-surface-container-low overflow-hidden rounded-xl group">
            <img alt="Texture detail" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuBUq0cgd2KTN0avbMRm1AQn530z3wrz3XxzxYNqBHOYy2obY1OGUxGfn3X8qEEfd6rs1GClvIM3i95-Ph0m8e0lE9w6qoMPz4ZgPIprHwuxajIurr-uIkmfSlA9sW37nruYOksKm1BrjVeiurwhLeHf8Q6o4zau00__lE4Js1ca6nM_aTpqUnq4FuYuSlk63Br8j9cJkWTqBDaWtC-G39LNj_cW5qofrQxul0UDMu0V8q3LcmDlo8bNWWIDWOr8Anb96-1UCexYIfxC" />
          </div>
          <div className="aspect-square bg-surface-container-low overflow-hidden rounded-xl group">
            <img alt="Lifestyle view" className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src="https://lh3.googleusercontent.com/aida-public/AB6AXuCTzd79kwC_G7oyX2LPJCO7TJX1-EL-83XU7Qe5CNGbqW80Nxk8E_4mvSrET1Nci2VB4ul-pVX6INmTPEjaeSfDthZocsUF_1wk6uiFyIEIv_DagZz0omIZ6Z_SbO6PCSQbHkSoYCvauKJjwU2w0865LmfWSx9hKQYubkArRw4GjIuNAcILBf9YpqbaFCvoCggUMuw5rvFd7NhZjG1kduAxJeaB5gHo0BPqgU29itdbX8WhoH_zrLAiw8g-fcCQYg-ZkSE56w4OUahm" />
          </div>
        </div>

        {/* Right: Product Information */}
        <div className="lg:col-span-5 lg:sticky lg:top-32 space-y-6">
          <header className="space-y-3">
            <p className="font-label-md text-primary tracking-widest uppercase text-sm">Limited Edition</p>
            <h1 className="font-headline-lg text-5xl text-on-surface">Lumière Silk Blouse</h1>
            <div className="flex items-center gap-4">
              <span className="font-headline-md text-3xl font-bold text-on-surface">$280.00</span>
              <span className="text-on-surface-variant line-through font-body-md text-lg">$345.00</span>
              <span className="bg-primary/10 text-primary px-3 py-1 rounded-full font-label-md text-xs">-15%</span>
            </div>
          </header>

          <div className="space-y-3 pt-4">
            <p className="font-label-md text-on-surface-variant uppercase text-xs">Color: Moonbeam White</p>
            <div className="flex gap-3">
              <button className="w-8 h-8 rounded-full border-2 border-primary bg-[#F9F9FF] p-0.5"><div className="w-full h-full rounded-full bg-white border border-slate-200"></div></button>
              <button className="w-8 h-8 rounded-full border-2 border-transparent bg-slate-900 p-0.5 hover:border-primary transition-all"></button>
              <button className="w-8 h-8 rounded-full border-2 border-transparent bg-violet-200 p-0.5 hover:border-primary transition-all"></button>
            </div>
          </div>

          <div className="space-y-3 pt-4">
            <div className="flex justify-between items-end">
              <label className="font-label-md text-on-surface-variant uppercase text-xs">Select Size</label>
              <button className="text-primary font-label-md text-xs underline underline-offset-4">Size Guide</button>
            </div>
            <div className="grid grid-cols-4 gap-3">
              {['XS', 'S', 'M', 'L'].map(size => (
                <button 
                  key={size}
                  onClick={() => setSelectedSize(size)}
                  className={`h-12 rounded-lg font-label-md transition-all uppercase ${selectedSize === size ? 'border-2 border-primary bg-primary/5 text-primary' : 'border border-outline-variant hover:border-primary hover:text-primary text-on-surface'}`}
                >
                  {size}
                </button>
              ))}
            </div>
          </div>

          <div className="pt-6 flex flex-col gap-4">
            <button className="w-full h-16 bg-primary-container text-on-primary font-button rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform shadow-[0_10px_20px_rgba(99,14,212,0.15)] hover:bg-primary">
              <ShoppingCart fill="currentColor" size={20} />
              ADD TO CART
            </button>
            <button className="w-full h-16 bg-secondary-container text-on-secondary-container font-button rounded-xl flex items-center justify-center gap-2 active:scale-[0.98] transition-transform hover:bg-secondary-fixed-dim">
              <Heart size={20} />
              SAVE TO WISHLIST
            </button>
          </div>

          {/* Info Grid */}
          <div className="grid grid-cols-2 gap-4 pt-6 border-t border-slate-100">
            <div className="flex gap-3 items-start">
              <Truck className="text-primary" size={24} />
              <div>
                <p className="font-label-md text-xs uppercase text-on-surface">Free Shipping</p>
                <p className="text-on-surface-variant text-[11px]">Orders over $200</p>
              </div>
            </div>
            <div className="flex gap-3 items-start">
              <Leaf className="text-primary" size={24} />
              <div>
                <p className="font-label-md text-xs uppercase text-on-surface">Ethically Sourced</p>
                <p className="text-on-surface-variant text-[11px]">100% Organic Silk</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Product Tabs Section */}
      <section className="mt-32">
        <div className="border-b border-outline-variant mb-12">
          <div className="flex gap-x-12 overflow-x-auto pb-6">
            {['description', 'details & care', 'reviews (124)'].map(tab => (
              <button 
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`font-label-md uppercase tracking-widest text-sm transition-colors whitespace-nowrap ${activeTab === tab ? 'text-on-surface relative after:content-[""] after:absolute after:-bottom-[26px] after:left-0 after:w-full after:h-0.5 after:bg-primary' : 'text-on-surface-variant hover:text-primary'}`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div className="space-y-6">
            <h3 className="font-headline-md text-3xl text-on-surface">The Pinnacle of Comfort</h3>
            <p className="font-body-lg text-on-surface-variant leading-relaxed">
              Crafted from our signature heavy-weight mulberry silk, the Lumière Blouse reimagines a wardrobe essential. Featuring a fluid silhouette that effortlessly drapes the body, it transition seamlessly from morning presentations to sunset soirées.
            </p>
            <p className="font-body-md text-on-surface-variant leading-relaxed">
              Every seam is hand-finished with meticulous attention to detail, ensuring a garment that feels as luxurious as it looks. The moonbeam finish offers a subtle pearlized glow that captures light from every angle.
            </p>
          </div>
          <div className="rounded-2xl overflow-hidden bg-surface-container-high h-[400px]">
            <img alt="Mood visual" className="w-full h-full object-cover" src="https://lh3.googleusercontent.com/aida-public/AB6AXuAyHTYCi85T3kBby8ePFmkBBgYigH0a_D6gJRWkgJd-FRLq_TnrVIJgkUC9ofwLdtndPI_YJwHJtfPTtRaJMKOlZiX3rQenOshI3dQzASMo2DYR-Ha867ZFnYlb3h6dVAW2ZEvmq1HK6zYAt6OUSaIsAaM5UFdak3r8o61RO0X92Hw88rYlrdF99iFV02VZW5tDPwmTqoajZxCRB7zo0XvwF3l2O1pDKKzbmkqjQ4cx0U8mHlPJsmjsCSmmsFtY5VDQhTtN0KYlx42G" />
          </div>
        </div>
      </section>

      {/* Related Products */}
      <section className="mt-32">
        <div className="flex justify-between items-end mb-12">
          <div>
            <p className="font-label-md text-primary tracking-widest uppercase mb-2 text-sm">Curated for You</p>
            <h2 className="font-headline-md text-3xl text-on-surface">Complete The Look</h2>
          </div>
          <Link to="/products" className="font-label-md text-primary uppercase text-sm flex items-center gap-2 group">
            View Entire Collection
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {relatedProducts.map(product => (
            <div key={product.id} className="group cursor-pointer">
              <div className="aspect-[3/4] rounded-xl overflow-hidden bg-surface-container relative mb-4">
                <img alt={product.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src={product.image} />
                <button className="absolute bottom-4 right-4 bg-white/90 backdrop-blur-md p-3 rounded-full shadow-lg opacity-0 group-hover:opacity-100 translate-y-4 group-hover:translate-y-0 transition-all text-on-surface hover:text-primary">
                  <Plus size={20} />
                </button>
              </div>
              <p className="font-label-md text-xs uppercase text-on-surface-variant mb-1">{product.category}</p>
              <h4 className="font-headline-md text-lg leading-tight mb-1 text-on-surface">{product.name}</h4>
              <p className="font-body-md text-on-surface font-semibold">{product.price}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
