import { ChevronLeft, ChevronRight, Heart } from 'lucide-react';
import { useState } from 'react';

const products = [
  {
    id: 1,
    category: "Knitwear",
    name: "Cashmere Oversized Crew",
    price: "$480.00",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBZRhGjHQcKxX0lIZwHKxUwyETe-_Ahj4fuQd3MNjcPkMNHTaGbkITkLd5GavoDQ7xhbirFt1ERMEG-QA3obWEpwuYoO-HzJnWEMFtWJBGWJJc_7sM7rmP-xtrDNfPm_FSXAnxIUU7atK5b87T9WsPOFt0W6f6EPRkhNZwG-k6-qBzcrwNAHnIwA97Pj9z67YhjzVGuRqnr60M2UEuqUH93nJJ8OviziiT7V77Y0yNPJW8G_-OEnlOv1yg0GEHFz2bGFzwNh6Lo6h_L",
    isNew: false
  },
  {
    id: 2,
    category: "Outerwear",
    name: "The Archive Wool Coat",
    price: "$1,250.00",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCGicZBUf7MAAtUWmBCrQLG7UffPaHz79QO2UmYNufNQgWb8hKxG2eDIDrGQkKnq9l9-d_b3er9cchiVv_SNFcB3tKvMiljeu7dMC6kwZvlNzt8zt7PaC55BskQugj8DgiXLHIo9I6vrWX-g87HSJ7oJXIMSh2pdNGSrgzmJcREwzadYjrquRfgRSgzL-JG6XmUG5SZlX9mednW4drthxzhfnPg4DMqbN5RMrK-Wxg1nNzLPSC48wx-dYQ7fOxyc0bFQrzxsLC4ZZ02",
    isNew: true
  },
  {
    id: 3,
    category: "Footwear",
    name: "Terra Chelsea Boot",
    price: "$620.00",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCLrZ0HT_GA82aHGgmdp1N1YpDMgl-O-RyAOs7dNkhYIS3dKyvakrRCXWXQCX_GlUWOKIF1-2Tx6my9IYD2DbjyzvV597FE8mfBTekUgOZyucRgqDBZX4p6EmwmtMqT-koKR-ObYNqfj2iIQIc80FJfLS3kdVtr2hEI8FTORlEwUOjBNKKdgF7YdeFC3BZ5sBXDjOPlSOoiwpMfQqWxJUTPstnJ4Ct1N-KhtFUIVTV6Pd-TOiOkzf13aGClcjVvlZQeOceT9j1JQDJM",
    isNew: false
  },
  {
    id: 4,
    category: "Shirts",
    name: "Raw Linen Button Down",
    price: "$245.00",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCeZ0kws0m36TP8OAqHjS-M0h-kIWI3Oo1oXjwrC9_SuBAjAQluaE3Gb4pGGCZEIH8TnQodaou1u_WPtB0FaSLad6iKzixFM7swL03_CJKHT81lr1KPZstAN7pVsucrblhlZIPOENibzCEYTBsFKjzmKFEE4vM4jXQFbtjlM1OCdsa2DgTr2TiRZFH6i6ZHqfGwOXG4h6JEtnjkgDrNammoV7nTgWcyQX2UKMArxi0XwajiC0lDCtCyGoVKbYFfI9o88hZz3e17NvFv",
    isNew: false
  },
  {
    id: 5,
    category: "Bottoms",
    name: "Silk Wide-Leg Trouser",
    price: "$590.00",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuBQZnqetfZeCVrqpx_pqSp78bhfH9la1ACtw_nBLaXQn7fS48JYZUAC7pfftGFMWTrTknQGtbMnZd7iXdjDkda232vY8T9ugtZVUv0KWnfZlzYeNv9YUaKXSxqyJlS42EIyoL1hoQgETJgdQEXKs0ybzhojhvonUxFb0zD_j1E1y0Ygq5sG1CxZSPNwEOBpbvdLi6jtS963J1Ew-KPRJUN2Ge4C06MZuOpq-Vrk5Tg-pqcPH1AM2MamP6bSmZ-7OlcK04MaZvDLTime",
    isNew: false
  },
  {
    id: 6,
    category: "Knitwear",
    name: "Merino Knit Polo",
    price: "$320.00",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCdzokxNuJBR0sRINmxi3L0MctGOC8-eStZl4M97f_SaAqyfITxo6BFiSU0BgS9RqLvhvbL9sMKv1F6QoZjXsbFmPNp88wuztF1q4SmmU5FVBv3My_15cHyxy6xH2edMuiv4uPKj4qXVtXpDpPQn6xDjnq52EzPwXo3YJk1C6TWrR4DZakzCsqsrOpbxzOxLpXwSS755sL-0Mr6gVuSEcaYhmm-XSGoJXwxgU0tpF1JbFgNXr6gV76SNRnfcUZ6pjBN3myRgUJygBhq",
    isNew: false
  },
  {
    id: 7,
    category: "Essentials",
    name: "The Heavyweight Tee",
    price: "$95.00",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCz1mWXlpSvayYaeZmxRLXLVXmI2OaAvklPiRwKbTXGs5WVxUYQyP_qkPI_z4gkuCh3iagqjEJ2RBoG0opSBa3u0RPoUYvgJTxPyVJK1rxsDO-6P2BhGYKwxtsn2VK_U344hSW6U9GSiT42s7owawFADWprKHeQW95Q7uEPRv52DEGurE_11k3eiOF7OudmH2amW14Y9f1hlOC4QYukaImAnuGJ-m2hrLwK7TNTYZAYzxJs6mnIzblgCpK7SimPHuJK3jGsjVhi1sOV",
    isNew: false
  },
  {
    id: 8,
    category: "Accessories",
    name: "24k Vermeil Link Chain",
    price: "$850.00",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAMjTSO1bwTETkJ-Mh7F2B-moUugz_cWsHgUyUixpYQz9rYNyY4Tfuruv6TMP3vn11Qejvge2ig4b0hZNuWBfFkxBckhXmQcNmhGz44XJyg2VMDCrqiGbyZ5ziZliyMQgUky8MnjwiglyAl4YiBulAJgd718ci368v90VDphuQzcl5UFknDFb2bwOoIvrOmF4n5k2aO96iTZ7PHlJkSlm_2PyvMRlTcvIvK7MQmSVPbmSzOdrgEWXaVHat0tRMj_WFR2p6EfaNNwunk",
    isNew: false
  }
];

export default function ProductListing() {
  const [favorites, setFavorites] = useState({});

  const toggleFavorite = (id) => {
    setFavorites(prev => ({...prev, [id]: !prev[id]}));
  };

  return (
    <div className="py-12 max-w-7xl mx-auto px-8">
      {/* Collection Header */}
      <div className="mb-16">
        <h1 className="font-headline-lg text-5xl text-on-surface mb-4">SS24 Essentials</h1>
        <p className="font-body-lg text-lg text-on-surface-variant max-w-2xl">A curated collection of timeless silhouettes, crafted with sustainable materials and an uncompromising eye for detail.</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-12">
        {/* Sidebar Filters */}
        <aside className="w-full lg:w-64 flex-shrink-0 space-y-10">
          <div>
            <h3 className="font-label-md text-sm uppercase mb-6 text-on-surface">Categories</h3>
            <div className="space-y-3">
              {['Outerwear', 'Knitwear', 'Accessories', 'Footwear'].map(cat => (
                <label key={cat} className="flex items-center gap-3 cursor-pointer group">
                  <input className="w-5 h-5 rounded border-outline-variant text-primary focus:ring-primary/20 bg-surface" type="checkbox" defaultChecked={cat === 'Knitwear'}/>
                  <span className={`font-body-md transition-colors ${cat === 'Knitwear' ? 'text-on-surface' : 'text-on-surface-variant group-hover:text-primary'}`}>{cat}</span>
                </label>
              ))}
            </div>
          </div>
          <div>
            <h3 className="font-label-md text-sm uppercase mb-6 text-on-surface">Price Range</h3>
            <div className="px-2">
              <input className="w-full h-1 bg-surface-container-highest rounded-lg appearance-none cursor-pointer accent-primary" type="range"/>
              <div className="flex justify-between mt-4 font-body-md text-on-surface-variant">
                <span>$100</span>
                <span>$2500+</span>
              </div>
            </div>
          </div>
          <div>
            <h3 className="font-label-md text-sm uppercase mb-6 text-on-surface">Color</h3>
            <div className="flex flex-wrap gap-3">
              <button className="w-8 h-8 rounded-full bg-slate-900 border-2 border-transparent ring-2 ring-offset-2 ring-primary transition-all"></button>
              <button className="w-8 h-8 rounded-full bg-stone-200 border-2 border-transparent hover:ring-2 hover:ring-offset-2 hover:ring-primary transition-all"></button>
              <button className="w-8 h-8 rounded-full bg-emerald-900 border-2 border-transparent hover:ring-2 hover:ring-offset-2 hover:ring-primary transition-all"></button>
              <button className="w-8 h-8 rounded-full bg-amber-100 border-2 border-transparent hover:ring-2 hover:ring-offset-2 hover:ring-primary transition-all"></button>
              <button className="w-8 h-8 rounded-full bg-violet-200 border-2 border-transparent hover:ring-2 hover:ring-offset-2 hover:ring-primary transition-all"></button>
            </div>
          </div>
          <div className="pt-8">
            <button className="w-full py-4 bg-primary text-on-primary font-button rounded-xl hover:bg-primary-container transition-colors shadow-lg shadow-primary/20">Apply Filters</button>
          </div>
        </aside>

        {/* Product Grid Content */}
        <section className="flex-grow">
          {/* Sorting & Count */}
          <div className="flex flex-col sm:flex-row justify-between items-center mb-10 gap-4">
            <span className="font-body-md text-on-surface-variant">Showing 24 products</span>
            <div className="flex items-center gap-4">
              <span className="font-label-md text-sm uppercase text-on-surface-variant">Sort By</span>
              <select className="bg-surface-container-low border-none rounded-lg font-body-md text-on-surface focus:ring-2 focus:ring-primary py-2 pr-10 pl-4 outline-none">
                <option>Newest Arrivals</option>
                <option>Price: Low to High</option>
                <option>Price: High to Low</option>
                <option>Most Popular</option>
              </select>
            </div>
          </div>

          {/* 4 Column Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-x-8 gap-y-12">
            {products.map(product => (
              <article key={product.id} className="group cursor-pointer">
                <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-surface-container mb-6 transition-transform duration-500 group-hover:-translate-y-1">
                  <img alt={product.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" src={product.image} />
                  <button 
                    onClick={(e) => { e.preventDefault(); toggleFavorite(product.id); }}
                    className={`absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center transition-colors ${favorites[product.id] ? 'text-error' : 'text-on-surface-variant hover:text-error'}`}
                  >
                    <Heart size={20} fill={favorites[product.id] ? 'currentColor' : 'none'} />
                  </button>
                  {product.isNew && (
                    <div className="absolute bottom-4 left-4 bg-primary text-white px-3 py-1 text-xs font-bold rounded-full">New</div>
                  )}
                </div>
                <div>
                  <p className="font-label-md text-sm uppercase text-on-surface-variant mb-1">{product.category}</p>
                  <h4 className="font-headline-md text-xl mb-2">{product.name}</h4>
                  <p className="font-body-md text-on-surface font-semibold">{product.price}</p>
                </div>
              </article>
            ))}
          </div>

          {/* Pagination */}
          <div className="mt-20 flex justify-center items-center gap-4">
            <button className="w-12 h-12 rounded-full border border-outline-variant flex items-center justify-center hover:bg-surface-container transition-colors">
              <ChevronLeft size={24} />
            </button>
            <div className="flex items-center gap-2">
              <button className="w-10 h-10 rounded-full bg-primary text-white font-label-md">1</button>
              <button className="w-10 h-10 rounded-full hover:bg-surface-container font-label-md text-on-surface-variant transition-colors">2</button>
              <button className="w-10 h-10 rounded-full hover:bg-surface-container font-label-md text-on-surface-variant transition-colors">3</button>
              <span className="px-2">...</span>
              <button className="w-10 h-10 rounded-full hover:bg-surface-container font-label-md text-on-surface-variant transition-colors">12</button>
            </div>
            <button className="w-12 h-12 rounded-full border border-outline-variant flex items-center justify-center hover:bg-surface-container transition-colors">
              <ChevronRight size={24} />
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
