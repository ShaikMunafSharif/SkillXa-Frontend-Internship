import { Search, Filter, Heart } from 'lucide-react';
import { useState } from 'react';

const searchResults = [
  {
    id: 1,
    type: "feature",
    title: "Celestial Silk Slip Gown",
    description: "100% Mulberry Silk • Hand-finished edges",
    price: "$420",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCJ5H3qC6yUDVAyA-jE3p7zLO0lWhTHacma9G0osI9paYO0gUhwb7D0M51R049nKN51yjzHumUwK_nVZeKlom454h9BpHbiNAFZEYzqDMln_ubz1gQC2T-PkxTul4f3V2HXh6XluMO9iZ4cjoFKhrymwjxh5Zu4ClDunaJjNmTRsn-ZQsd8XWttuEHq9LUM6k40wYg-c5F7lyhWDlm5Ihp5omx2_LvqEa73hdS_kVnZkx9dU_HNPnfsTcuF2JYyg9q6b5q2whXL1UcA",
    badge: "Editor's Pick"
  },
  {
    id: 2,
    type: "standard",
    title: "Structured Organza Top",
    description: "Ivory White • Limited Run",
    price: "$285",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuDiihsnHWU3da4NGTYOl4ZGdcTiR1_dFxDXDglOaK0a6VmsRPUxRn4DMooKMF_g93thlIGAzHSNc-jFp65nSP3GGHpQ6VsnE9cOV0jwh0xVvXSyUNf-VvSFwT1ety6kvsEp6ixgudaQaDiJqXLElhO-_bfU476DCNxbXYF-nMJytkW1BoDcAgOTBUypCxTGs_vb7hgpkNW4r6xuSF2sx8TnMzLpnFAIeBHeX_adTd7UPR51m7v03oMwNIMvuvgAi8RgWUp3jJHNITIE"
  },
  {
    id: 3,
    type: "standard",
    title: "Aura Signature Scarf",
    description: "Sunset Gradient",
    price: "$120",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuCbONEkth53VTW4N89D8hghllar3Q5dU1DIBZEy2dmlTCNuhlkS9PwEf-JN9YagHPJlZ8Inxx5KeIEcsQzS8fcantHZh52AybkfwshwLWwVd6flkKAdJ67yBanZAlHXeGTr2D6QYUGoeXnGsplVn8D0i7qGkyGsPbx5XqUvVS_m8TjTdSGCUzEUQcjGbg8Q_Mbps3XOclZ-HYw3Ro-yswKPldGgkTLvB1hNBFISidT-IJ6HPJoZWB-fyzOt32nsQKLpuHilKilNmIHV"
  },
  {
    id: 4,
    type: "standard",
    title: "Summer Breeze Gown",
    description: "Lightweight Silk Chiffon",
    price: "$350",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuD_k3M7hFHjAPDTHc91A0zQ0FSJqjRquV9_uKX-z-KGsIVCR6-PqUEKAAuOMv_Aj9INL8mZHzNr0Fb6tAnRL2Lw8krTV-Jk4GRhCMBHKWIiD13c8JLo2gK5VNwX6G2aZOQlMN2_tGLYjfx6X4wN0MlAu97de7vTxBwHue-X2G7AzQhfoFCL8pRlYL30HEDWXn4wyA9hWrDdB0N1E4Kgdj4qHZbDEXIr4vrJcgE1cIqjEeImYcOTYSz0vrV_FgozZsUKhUN-SZxmBDKE"
  },
  {
    id: 5,
    type: "standard",
    title: "Palazzo Silk Trousers",
    description: "Deep Violet • Tailored Fit",
    price: "$310",
    image: "https://lh3.googleusercontent.com/aida-public/AB6AXuAtTCBSuNjnBL6KQp9DpI591lEUwuVEF_l-_95ilpdgk6zN8QXOB7pGCKwW_H9SAdlHozfvCrm6a7IOK3RPgvqmxCtn-q7hF4cc3i7zmPiU22r52DLa0p4OL2I0MtmoLuJS1nVnTHzYBOXQhjc7IYCSOYwYZyGinQx4zrh0GmX8iQSDZCBGtoj-tbk19onNPywPnCeCW1UMtUdCaPbe3Wr8Ct4xnMpjj9Tq2FsL1kv_n093gpbIHQqVNu-ju0bK07FgdEpT5r24MT8q"
  }
];

export default function SearchResults() {
  const [favorites, setFavorites] = useState({});

  const toggleFavorite = (id) => {
    setFavorites(prev => ({...prev, [id]: !prev[id]}));
  };

  return (
    <div className="py-12 px-8 max-w-7xl mx-auto">
      {/* Search Header Section */}
      <section className="mb-12">
        <div className="flex flex-col gap-6">
          <div className="flex items-center gap-2 text-primary">
            <Search size={20} />
            <span className="font-label-md uppercase tracking-widest text-sm">Search Results</span>
          </div>
          <h1 className="font-headline-lg text-5xl text-on-surface">“Summer Silk”</h1>
          <p className="font-body-lg text-lg text-on-surface-variant max-w-2xl">Displaying 24 exquisite pieces found for your search. Each garment is curated for its material integrity and silhouette.</p>
        </div>
      </section>

      {/* Filters & Layout Controls */}
      <section className="mb-12 flex flex-col md:flex-row justify-between items-start md:items-center gap-6 border-b border-surface-variant pb-8">
        <div className="flex flex-wrap gap-4">
          <button className="flex items-center gap-2 px-6 py-3 bg-primary text-on-primary rounded-full font-button transition-transform active:scale-95">
            <Filter size={18} />
            Filters
          </button>
          <button className="px-6 py-3 bg-surface-container-low text-on-surface-variant rounded-full font-button hover:bg-surface-container-high transition-colors">Category</button>
          <button className="px-6 py-3 bg-surface-container-low text-on-surface-variant rounded-full font-button hover:bg-surface-container-high transition-colors">Price Range</button>
          <button className="px-6 py-3 bg-surface-container-low text-on-surface-variant rounded-full font-button hover:bg-surface-container-high transition-colors">Color</button>
        </div>
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-2 text-on-surface-variant font-label-md uppercase text-sm">
            Sort By: 
            <select className="bg-transparent border-none outline-none focus:ring-0 font-bold text-on-surface cursor-pointer">
              <option>Recommended</option>
              <option>Newest First</option>
              <option>Price: Low to High</option>
              <option>Price: High to Low</option>
            </select>
          </div>
        </div>
      </section>

      {/* Results Grid */}
      <section className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Bento-style Feature Result (Spans 8 columns) */}
        <div className="md:col-span-8 group cursor-pointer">
          <div className="relative aspect-[16/10] overflow-hidden rounded-xl bg-surface-container-low shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <img alt={searchResults[0].title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src={searchResults[0].image} />
            <div className="absolute top-6 left-6 px-4 py-1 bg-white/90 backdrop-blur-md rounded-full text-primary font-label-md text-[12px] uppercase tracking-widest">{searchResults[0].badge}</div>
            <button 
              onClick={(e) => { e.preventDefault(); toggleFavorite(searchResults[0].id); }}
              className={`absolute bottom-6 right-6 w-12 h-12 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center transition-colors ${favorites[searchResults[0].id] ? 'text-error' : 'text-on-surface-variant hover:text-error'}`}
            >
              <Heart fill={favorites[searchResults[0].id] ? 'currentColor' : 'none'} size={24} />
            </button>
          </div>
          <div className="mt-6 flex justify-between items-start">
            <div>
              <h3 className="font-headline-md text-3xl text-on-surface">{searchResults[0].title}</h3>
              <p className="font-body-md text-on-surface-variant mt-1">{searchResults[0].description}</p>
            </div>
            <span className="font-headline-md text-3xl text-primary">{searchResults[0].price}</span>
          </div>
        </div>

        {/* Side Result 1 (Spans 4 columns) */}
        <div className="md:col-span-4 group cursor-pointer">
          <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-surface-container-low shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
            <img alt={searchResults[1].title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src={searchResults[1].image} />
            <button 
              onClick={(e) => { e.preventDefault(); toggleFavorite(searchResults[1].id); }}
              className={`absolute bottom-6 right-6 w-12 h-12 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center transition-colors ${favorites[searchResults[1].id] ? 'text-error' : 'text-on-surface-variant hover:text-error'}`}
            >
              <Heart fill={favorites[searchResults[1].id] ? 'currentColor' : 'none'} size={24} />
            </button>
          </div>
          <div className="mt-6">
            <h3 className="font-headline-md text-2xl text-on-surface">{searchResults[1].title}</h3>
            <p className="font-body-md text-on-surface-variant mt-1">{searchResults[1].description}</p>
            <span className="block mt-2 font-headline-md text-2xl text-primary">{searchResults[1].price}</span>
          </div>
        </div>

        {/* Row 2: Standard Cards (4 columns each) */}
        {searchResults.slice(2).map(product => (
          <div key={product.id} className="md:col-span-4 group cursor-pointer">
            <div className="relative aspect-[3/4] overflow-hidden rounded-xl bg-surface-container-low shadow-[0_20px_40px_rgba(124,58,237,0.04)]">
              <img alt={product.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" src={product.image} />
              <button 
                onClick={(e) => { e.preventDefault(); toggleFavorite(product.id); }}
                className={`absolute bottom-6 right-6 w-12 h-12 bg-white/90 backdrop-blur-md rounded-full flex items-center justify-center transition-colors ${favorites[product.id] ? 'text-error' : 'text-on-surface-variant hover:text-error'}`}
              >
                <Heart fill={favorites[product.id] ? 'currentColor' : 'none'} size={24} />
              </button>
            </div>
            <div className="mt-6">
              <h3 className="font-headline-md text-2xl text-on-surface">{product.title}</h3>
              <p className="font-body-md text-on-surface-variant mt-1">{product.description}</p>
              <span className="block mt-2 font-headline-md text-2xl text-primary">{product.price}</span>
            </div>
          </div>
        ))}
      </section>

      {/* Newsletter / CTA */}
      <section className="mt-32 bg-surface-container rounded-3xl p-16 flex flex-col items-center text-center gap-6 border border-primary/5">
        <h2 className="font-headline-lg text-5xl text-on-surface">Never miss a curation.</h2>
        <p className="font-body-lg text-lg text-on-surface-variant max-w-xl">Join the AURA circle for early access to limited collections and exclusive style editorials.</p>
        <form className="mt-4 flex w-full max-w-md gap-4" onSubmit={e => e.preventDefault()}>
          <input className="flex-1 bg-surface-container-lowest border-none rounded-full px-8 py-4 focus:ring-2 focus:ring-primary font-body-md outline-none" placeholder="Enter your email" type="email" />
          <button type="submit" className="bg-primary hover:bg-primary-container text-on-primary px-10 py-4 rounded-full font-button transition-transform active:scale-95 shadow-lg shadow-primary/20">Join</button>
        </form>
      </section>
    </div>
  );
}
