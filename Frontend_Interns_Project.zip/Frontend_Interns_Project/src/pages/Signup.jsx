export default function Signup() { return <div className='p-24 text-center'><h1 className='text-4xl font-headline-lg'>{$page}</h1></div>; }
